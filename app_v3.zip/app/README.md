# 🎬 제네시스 AI 스튜디오

YouTube 콘텐츠 분석부터 AI 영상 자동 생성까지, 블루가드 마케팅을 위한 올인원 AI 솔루션

---

## 📌 프로젝트 개요

**제네시스 AI 스튜디오**는 YouTube 데이터 수집, AI 기반 콘텐츠 분석, 마케팅 썸네일 생성, 그리고 AI 영상 자동 생성을 통합한 Streamlit 기반 웹 애플리케이션입니다.

### 주요 기능

| 기능                       | 설명                                | 사용 기술           |
| -------------------------- | ----------------------------------- | ------------------- |
| 📰 **YouTube 데이터 수집** | 키워드 기반 영상 검색 및 자막 추출  | YouTube Data API v3 |
| 🛒 **네이버 쇼핑 검색**    | 경쟁 제품 가격/트렌드 분석          | Naver Open API      |
| 🧠 **AI 콘텐츠 분석**      | 트렌드 분석 및 마케팅 프롬프트 생성 | Gemini 2.5 Flash    |
| 🖼️ **AI 썸네일 생성**      | 마케팅용 고품질 썸네일 자동 생성    | Gemini 3 Pro Image  |
| 🎬 **AI 영상 생성**        | 마케팅 숏폼 영상 자동 생성          | Veo 3.1 Fast        |

---

## 🛠️ 기술 스택

```
Frontend:     Streamlit + Neobrutalism UI
AI Models:    Google Gemini 2.5/3.0, Veo 3.1
Storage:      Google Cloud Storage
APIs:         YouTube Data API, Naver Open API
Language:     Python 3.10+
```

---

## 📦 설치 방법

### 1. 필수 요구사항

- Python 3.10 이상
- Google Cloud Platform 계정
- 유효한 API 키들 (아래 참조)

### 2. 패키지 설치

```bash
pip install streamlit google-generativeai google-cloud-storage youtube-transcript-api requests
```

### 3. API 키 설정

`app.py` 상단의 설정 영역에서 다음 값들을 수정하세요:

```python
# YouTube API
YOUTUBE_API_KEY = "YOUR_YOUTUBE_API_KEY"

# Gemini API
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"

# 네이버 쇼핑 API (선택)
NAVER_CLIENT_ID = "YOUR_NAVER_CLIENT_ID"
NAVER_CLIENT_SECRET = "YOUR_NAVER_CLIENT_SECRET"

# GCP 설정
GOOGLE_CLOUD_PROJECT_ID = "YOUR_PROJECT_ID"
GCS_BUCKET_NAME = "YOUR_BUCKET_NAME"
```

### 4. GCP 서비스 계정 키

서비스 계정 키 파일 (`key.json`)을 `app/` 디렉토리에 배치하세요:

```bash
app/
├── app.py
├── key.json    # ← 여기
└── ...
```

---

## 🚀 실행 방법

```bash
cd app
python -m streamlit run app.py
```

브라우저에서 `http://localhost:8501` 접속

---

## 📂 프로젝트 구조

```
work_vibe/
├── app/
│   ├── app.py              # 메인 Streamlit 애플리케이션
│   ├── key.json            # GCP 서비스 계정 키 (gitignore)
│   ├── .streamlit/
│   │   └── config.toml     # Streamlit 설정
│   └── veo_final.mp4       # 생성된 영상 (예시)
│
└── genesis_kr/             # 원본 파이프라인 참조
    ├── pipeline_v11.py
    ├── config.py
    └── design_doc.txt
```

---

## 🎯 사용 가이드

### Step 1: 데이터 수집 (📰 YouTube 탭)

1. 검색 키워드 입력 (예: "해충 퇴치")
2. 수집할 영상 수 선택 (1-10개)
3. "수집 시작" 클릭
4. 자막 + 메타데이터가 GCS에 저장됨

### Step 2: AI 분석 (🧠 AI 분석 탭)

1. 데이터 수집 완료 후 "AI 분석 시작" 클릭
2. Gemini가 트렌드 분석 및 영상 프롬프트 생성
3. 생성된 프롬프트 편집 가능

### Step 3: 영상 생성 (🎬 영상 탭)

1. AI 분석 완료 후 "영상 생성" 클릭
2. Veo가 8초 마케팅 영상 생성
3. 완료 후 미리보기 및 다운로드

### 추가 기능

- **🛒 네이버 탭**: 경쟁 제품 가격 조사
- **🖼️ 썸네일 탭**: AI 마케팅 썸네일 생성
- **📦 제품 선택**: 사이드바에서 블루가드 15개 제품 중 선택

---

## 📦 블루가드 제품 카탈로그

| 제품명                  | 카테고리  | 타겟      |
| ----------------------- | --------- | --------- |
| 벅스델타                | 해충방제  | 날벌레    |
| 벅스델타S               | 해충방제  | 보행해충  |
| 블루가드 바퀴벌레겔     | 바퀴벌레  | 바퀴벌레  |
| 블루가드 좀벌레트랩     | 트랩      | 좀벌레    |
| 블루가드 화랑곡나방트랩 | 트랩      | 나방      |
| 뱀이싹                  | 기피제    | 뱀        |
| 쥐싹킬                  | 쥐약      | 쥐        |
| 싹보내 퇴치기           | 퇴치기    | 두더지/뱀 |
| 싹보내G 퇴치기          | 퇴치기    | 야생동물  |
| 모기싹                  | 해충방제  | 모기      |
| 개미싹                  | 해충방제  | 개미      |
| 파리싹                  | 해충방제  | 파리      |
| 냄새싹                  | 탈취/방향 | 악취      |
| 블루가드올인원          | 종합      | 다용도    |

---

## 🔧 주요 함수

| 함수명                          | 기능              |
| ------------------------------- | ----------------- |
| `search_youtube_videos()`       | YouTube 영상 검색 |
| `get_transcript()`              | 자막 추출         |
| `search_naver_shopping()`       | 네이버 쇼핑 검색  |
| `analyze_with_gemini()`         | Gemini AI 분석    |
| `generate_thumbnail()`          | AI 썸네일 생성    |
| `generate_video_long_running()` | Veo 영상 생성     |
| `analyze_sentiment()`           | 댓글 감성 분석    |
| `upload_to_gcs()`               | GCS 업로드        |

---

## ⚙️ 환경 설정

### Streamlit 설정 (`.streamlit/config.toml`)

```toml
[theme]
base = "light"
primaryColor = "#FF6B6B"

[server]
headless = true
port = 8501
```

---

## 🔐 보안 주의사항

> [!CAUTION]
> 다음 파일들은 절대 Git에 커밋하지 마세요:
>
> - `key.json` (GCP 서비스 계정 키)
> - API 키가 하드코딩된 파일

`.gitignore` 예시:

```
key.json
*.mp4
__pycache__/
.env
```

---

## 📄 라이선스

이 프로젝트는 내부 사용 목적으로 개발되었습니다.

---

## 🤝 문의

블루가드 마케팅팀 | Genesis AI v3.0
