# ==========================================
# ☁️ Google Cloud Storage 함수
# ==========================================
import json
import streamlit as st
from google.cloud import storage

from config import GCS_BUCKET_NAME


def upload_to_gcs(
    data,
    bucket_name: str = GCS_BUCKET_NAME,
    filename: str = "",
    content_type: str = "application/json",
) -> bool:
    """GCS에 데이터 업로드"""
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(filename)

        if content_type == "application/json":
            blob.upload_from_string(
                json.dumps(data, ensure_ascii=False, indent=2),
                content_type=content_type,
            )
        else:
            blob.upload_from_string(data, content_type=content_type)

        return True
    except Exception as e:
        st.error(f"GCS 업로드 에러: {e}")
        return False


def read_from_gcs(bucket_name: str = GCS_BUCKET_NAME, filename: str = "") -> str | None:
    """GCS에서 데이터 읽기"""
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(filename)
        return blob.download_as_text()
    except Exception:
        return None


def download_from_gcs(bucket_name: str, blob_path: str) -> bytes | None:
    """GCS에서 바이너리 데이터 다운로드"""
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(blob_path)
        return blob.download_as_bytes()
    except Exception as e:
        st.error(f"GCS 다운로드 실패: {e}")
        return None


def list_gcs_files(bucket_name: str = GCS_BUCKET_NAME, prefix: str = "") -> list:
    """GCS 버킷 내 파일 목록 조회"""
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blobs = bucket.list_blobs(prefix=prefix)
        return [blob.name for blob in blobs]
    except Exception as e:
        st.error(f"GCS 목록 조회 실패: {e}")
        return []
