# ==========================================
# 🤖 Gemini AI 함수
# Vertex AI Pipelines 호환 설계
# ==========================================
import json
from typing import Optional, Callable

from config import GEMINI_MODEL_NAME, GEMINI_IMAGE_MODEL


# ==========================================
# 📝 프롬프트 빌더 (Google AI 가이드 기반)
# ==========================================


def build_image_prompt(
    product: dict,
    hook_text: str,
    style: str = "드라마틱",
    color_scheme: str = "블루 그라디언트",
    aspect_ratio: str = "9:16",
) -> str:
    """
    Google AI 이미지 프롬프트 가이드 기반 프롬프트 생성

    키워드 나열 대신 장면을 설명하는 방식
    """
    style_map = {
        "드라마틱": "cinematic dramatic lighting with high contrast shadows",
        "깔끔한": "clean minimalist modern professional design",
        "공포형": "dark ominous atmosphere with suspenseful horror elements",
        "유머형": "bright playful cartoon-like fun vibrant style",
    }

    color_map = {
        "블루 그라디언트": "deep blue gradient background fading from navy to cyan",
        "레드 경고": "urgent red warning tones with alert-style accents",
        "그린 자연": "natural forest green with organic earthy tones",
        "옐로우 주목": "attention-grabbing yellow with energetic golden highlights",
    }

    aspect_map = {
        "9:16": "vertical portrait format optimized for mobile phone screens",
        "16:9": "horizontal landscape format for YouTube thumbnails",
        "1:1": "square format for Instagram posts",
    }

    # 장면 설명 방식 프롬프트 (키워드 나열 X)
    prompt = f"""
Create a HIGH IMPACT marketing thumbnail for Korean pest control product.

SCENE DESCRIPTION:
The image shows a powerful visual representation of "{product["name"]}" pest control product.
The main text "{hook_text}" appears in GIANT bold Korean typography with black outline and slight 3D effect.
This text dominates the upper third of the frame, immediately grabbing attention.

VISUAL COMPOSITION:
- {aspect_map.get(aspect_ratio, "vertical portrait format")}
- {color_map.get(color_scheme, "bold gradient background")}
- {style_map.get(style, "dramatic professional marketing style")}
- The product concept is represented through before/after split design
- Left side shows problem: pests, dirt, infestation (dark, concerning)
- Right side shows solution: clean, pest-free, protected (bright, reassuring)

TYPOGRAPHY REQUIREMENTS:
- Main hook text: "{hook_text}"
- Font style: Extra bold sans-serif, slightly tilted for dynamic energy
- Text color: Bright yellow (#FFEB3B) with thick black outline
- Position: Upper center, maximum visibility

CAMERA AND LIGHTING:
- Low-angle perspective looking slightly upward (creates authority)
- Dramatic three-point lighting with key light from upper right
- Subtle rim light creating separation from background

QUALITY: Photorealistic, 4K resolution, no watermarks, professional advertising quality.
"""
    return prompt.strip()


def build_video_prompt(
    product: dict,
    scenario: dict,
    style: str = "cinematic",
    mood: str = "dramatic",
    include_audio: bool = True,
) -> str:
    """
    Google AI Veo 프롬프트 가이드 기반 영상 프롬프트 생성

    필수 요소: 주제, 동작, 스타일, 카메라, 분위기
    """
    style_keywords = {
        "cinematic": "cinematic film-like quality with shallow depth of field",
        "documentary": "documentary-style realistic natural footage",
        "commercial": "polished commercial advertisement broadcast quality",
        "horror": "dark suspenseful horror movie aesthetic with tension",
    }

    mood_keywords = {
        "dramatic": "dramatic intense high-stakes atmosphere",
        "calm": "calm serene peaceful soothing environment",
        "urgent": "urgent fast-paced action with quick movements",
        "hopeful": "hopeful optimistic uplifting bright feeling",
    }

    hook = scenario.get("hook", f"{product['name']} - {product['target']} 퇴치")
    script = scenario.get("script", "Professional pest control product in action")

    # Veo 프롬프트 작성 기본사항 적용
    prompt = f"""
SUBJECT: A professional pest control solution "{product["name"]}" designed for {product["target"]}.

ACTION: The scene transitions from a problem state (pest infestation) to a solution state (pest-free clean environment). 
A subtle mist or spray effect demonstrates the product's powerful action.

STYLE: {style_keywords.get(style, "cinematic professional quality")}.
{mood_keywords.get(mood, "dramatic impactful atmosphere")}.

CAMERA MOVEMENT: 
- Opening: Wide establishing shot of the scene
- Middle: Slow dolly-in toward the product in action
- Close: Low-angle hero shot of the protected space

COMPOSITION:
- Vertical 9:16 format for mobile shortform
- Clean visual hierarchy with product prominence
- Before/after visual contrast

LIGHTING AND MOOD:
- Cool blue tones transitioning to warm golden light
- Professional three-point lighting setup
- Subtle lens flare during transformation moment

SCENARIO DETAILS:
{script}

HOOK TEXT ON SCREEN: "{hook}"
"""

    # 오디오 프롬프트 추가 (Veo 3 지원)
    if include_audio:
        prompt += f"""
AUDIO ELEMENTS:
- Background: Low suspenseful hum builds tension initially
- SFX: Satisfying spray sound effect during product action
- Transition: Crisp clean "whoosh" sound as scene transforms
- End: Brief triumphant musical sting with resolution
"""

    return prompt.strip()


def build_multi_style_prompts(product: dict, base_hook: str) -> list:
    """
    3가지 스타일의 후킹 프롬프트 동시 생성

    Returns:
        list: [공포형, 정보형, 유머형] 프롬프트
    """
    styles = [
        {
            "type": "공포형",
            "hook": f"😱 {base_hook}",
            "style": "공포형",
            "color": "레드 경고",
            "scenario": {
                "hook": base_hook,
                "script": "Dark room reveals pest infestation. Dramatic spray effect. Pests flee. Clean bright result.",
            },
        },
        {
            "type": "정보형",
            "hook": f"💡 {base_hook}",
            "style": "깔끔한",
            "color": "블루 그라디언트",
            "scenario": {
                "hook": base_hook,
                "script": "Professional expert demonstrates product. Stats overlay. Scientific visualization. Trusted result.",
            },
        },
        {
            "type": "유머형",
            "hook": f"😂 {base_hook}",
            "style": "유머형",
            "color": "옐로우 주목",
            "scenario": {
                "hook": base_hook,
                "script": "Cartoon-style pest party interrupted. Comic spray effect. Pests scatter comedically. Happy ending.",
            },
        },
    ]

    result = []
    for s in styles:
        result.append(
            {
                "type": s["type"],
                "hook": s["hook"],
                "image_prompt": build_image_prompt(
                    product, s["hook"], s["style"], s["color"]
                ),
                "video_prompt": build_video_prompt(
                    product,
                    s["scenario"],
                    style="horror" if s["type"] == "공포형" else "commercial",
                    mood="urgent" if s["type"] == "공포형" else "hopeful",
                ),
            }
        )

    return result


# ==========================================
# 🧠 AI 분석 함수
# ==========================================


def analyze_with_gemini(
    json_text: str, product: Optional[dict] = None, logger: Optional[Callable] = None
) -> str:
    """
    Gemini로 마케팅 분석 및 영상 프롬프트 생성

    Args:
        json_text: 분석할 데이터 (JSON 문자열)
        product: 제품 정보 (선택)
        logger: 로그 함수 (Streamlit 또는 print)
    """
    try:
        from google import genai
        from google.genai import types

        client = genai.Client()

        # 제품 정보가 있으면 포함
        product_info = ""
        if product:
            product_info = f"""
[제품]: {product["name"]}
[설명]: {product["description"]}
[타겟]: {product["target"]}
"""

        prompt = f"""
[역할]: AI 비디오 디렉터
{product_info}
[데이터]: {json_text}
[요청]: 
1. Veo로 영상을 만들 영어 프롬프트를 작성해.
2. 조건: 오직 '영어 프롬프트 문장'만 출력해.
3. 스타일: Cinematic, 4k quality, photorealistic, 9:16 vertical shortform.
4. 제품 특성을 반영한 마케팅 영상 프롬프트 작성.
"""

        response = client.models.generate_content(
            model="gemini-3-pro-preview",
            contents=prompt,
            config=types.GenerateContentConfig(
                thinking_config=types.ThinkingConfig(
                    thinking_level=types.ThinkingLevel.LOW
                )
            ),
        )
        return response.text
    except Exception as e:
        error_msg = f"Gemini 오류: {e}"
        if logger:
            logger(error_msg)
        return error_msg


def generate_thumbnail(
    product_name: str,
    hook_text: str,
    style: str = "드라마틱",
    color_scheme: str = "블루 그라디언트",
    logger: Optional[Callable] = None,
) -> bytes | str:
    """
    Gemini로 마케팅 썸네일 이미지 생성 (강화된 프롬프트)

    Args:
        product_name: 제품명
        hook_text: 후킹 문구
        style: 스타일 (드라마틱/깔끔한/공포형/유머형)
        color_scheme: 색상 테마
        logger: 로그 함수

    Returns:
        bytes: 이미지 데이터 (성공 시)
        str: 오류 메시지 (실패 시)
    """
    try:
        from google import genai
        from google.genai.types import GenerateContentConfig, Modality

        client = genai.Client()

        # 향상된 프롬프트 빌더 사용
        product = {"name": product_name, "target": "해충", "description": ""}
        prompt = build_image_prompt(product, hook_text, style, color_scheme)

        if logger:
            logger(f"🖼️ 썸네일 생성 중: {product_name} ({style})")

        response = client.models.generate_content(
            model=GEMINI_IMAGE_MODEL,
            contents=prompt,
            config=GenerateContentConfig(
                response_modalities=[Modality.TEXT, Modality.IMAGE],
            ),
        )

        if response.candidates and response.candidates[0].content.parts:
            for part in response.candidates[0].content.parts:
                if part.inline_data:
                    import base64

                    img_data = part.inline_data.data
                    if isinstance(img_data, str):
                        img_data = base64.b64decode(img_data)
                    if logger:
                        logger(f"✅ 이미지 생성 완료 ({len(img_data):,} bytes)")
                    return img_data

        return response.text if hasattr(response, "text") else "이미지 생성 실패"

    except Exception as e:
        return f"썸네일 생성 오류: {e}"


def generate_multi_thumbnails(
    product: dict, base_hook: str, logger: Optional[Callable] = None
) -> list:
    """
    3가지 스타일의 썸네일 동시 생성

    Returns:
        list: [{"type": "공포형", "image": bytes, ...}, ...]
    """
    styles = [
        ("공포형", "레드 경고"),
        ("정보형", "블루 그라디언트"),
        ("유머형", "옐로우 주목"),
    ]

    results = []
    for style_type, color in styles:
        hook = f"{base_hook}"
        if logger:
            logger(f"🎨 {style_type} 썸네일 생성 중...")

        # 스타일 매핑
        style_map = {"공포형": "공포형", "정보형": "깔끔한", "유머형": "유머형"}

        img = generate_thumbnail(
            product["name"],
            hook,
            style=style_map.get(style_type, "드라마틱"),
            color_scheme=color,
            logger=logger,
        )

        results.append(
            {
                "type": style_type,
                "hook": hook,
                "image": img if isinstance(img, bytes) else None,
                "error": img if isinstance(img, str) else None,
            }
        )

    return results


def generate_marketing_strategy(
    collected_data: dict, logger: Optional[Callable] = None
) -> dict:
    """
    AI 기반 종합 마케팅 전략 생성
    Vertex AI Pipeline 컴포넌트로 사용 가능

    Args:
        collected_data: 수집된 데이터 (youtube_data, naver_data, product)
        logger: 로그 함수

    Returns:
        dict: 마케팅 전략 JSON
    """
    try:
        from google import genai
        from google.genai import types

        client = genai.Client()

        product = collected_data.get("product", {})

        # 확장된 YouTube 데이터 처리
        youtube_data = collected_data.get("youtube_data", [])
        if isinstance(youtube_data, dict):
            youtube_data = youtube_data.get("videos", [])

        youtube_summary = "\n".join(
            [
                f"- {d.get('title', '')}: {d.get('transcript', '')[:300]}..."
                for d in youtube_data[:3]
            ]
        )

        # 페인/게인 포인트 추가
        pain_points = collected_data.get("pain_points", [])
        gain_points = collected_data.get("gain_points", [])

        pain_summary = (
            "\n".join([f"- {p['text'][:100]}" for p in pain_points[:5]])
            if pain_points
            else "없음"
        )
        gain_summary = (
            "\n".join([f"- {g['text'][:100]}" for g in gain_points[:5]])
            if gain_points
            else "없음"
        )

        naver_summary = "\n".join(
            [
                f"- {d.get('title', '')}: {d.get('price', 0):,}원 ({d.get('mall', '')})"
                for d in collected_data.get("naver_data", [])[:5]
            ]
        )

        prompt = f"""
[역할]: 전문 마케팅 전략가 및 숏폼 콘텐츠 기획자
[제품]: {product.get("name", "")} - {product.get("description", "")} (타겟: {product.get("target", "")})

[수집된 YouTube 리뷰 데이터]:
{youtube_summary}

[고객 페인포인트 (댓글 분석)]:
{pain_summary}

[고객 게인포인트 (긍정 피드백)]:
{gain_summary}

[경쟁사 네이버 쇼핑 데이터]:
{naver_summary}

[요청]: 다음 항목을 JSON 형식으로 출력해주세요:

{{
    "target_persona": {{
        "age": "주요 타겟 연령대",
        "pain_points": ["고객의 고통 포인트 3가지"],
        "desires": ["고객이 원하는 것 3가지"]
    }},
    "hooking_points": [
        {{"type": "공포형", "hook": "후킹 문구 (첫 3초 시청자 사로잡기)", "explanation": "왜 효과적인지"}},
        {{"type": "정보형", "hook": "후킹 문구", "explanation": "왜 효과적인지"}},
        {{"type": "유머형", "hook": "후킹 문구", "explanation": "왜 효과적인지"}}
    ],
    "shortform_scenarios": [
        {{
            "title": "시나리오 제목",
            "type": "공포형/정보형/유머형",
            "script": "8초 영상 스크립트 (씬별 설명)",
            "thumbnail_text": "썸네일 텍스트"
        }}
    ],
    "sns_copies": {{
        "instagram": "인스타그램용 캡션 (해시태그 포함)",
        "youtube_shorts": "유튜브 쇼츠 제목",
        "tiktok": "틱톡용 캡션"
    }},
    "video_prompt": "Veo 영상 생성용 영어 프롬프트 (주제/동작/스타일/카메라/분위기 포함)",
    "thumbnail_prompt": "썸네일 이미지 생성용 영어 프롬프트 (장면 설명 방식)"
}}

중요: 반드시 유효한 JSON만 출력하세요.
"""

        if logger:
            logger("🧠 Gemini AI 분석 중...")

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
            ),
        )

        strategy_text = response.text.strip()
        if "```json" in strategy_text:
            strategy_text = strategy_text.split("```json")[1].split("```")[0]
        elif "```" in strategy_text:
            strategy_text = strategy_text.split("```")[1].split("```")[0]

        strategy = json.loads(strategy_text)

        if logger:
            logger("✅ 마케팅 전략 생성 완료!")

        return strategy

    except Exception as e:
        return {"error": str(e)}
