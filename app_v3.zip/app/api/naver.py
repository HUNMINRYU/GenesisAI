# ==========================================
# 🛒 네이버 쇼핑 API 함수
# ==========================================
import streamlit as st
import requests

from config import NAVER_CLIENT_ID, NAVER_CLIENT_SECRET


def search_naver_shopping(keyword: str, max_results: int = 10) -> list:
    """네이버 쇼핑 API로 상품 검색"""
    if not NAVER_CLIENT_ID or not NAVER_CLIENT_SECRET:
        return []

    url = "https://openapi.naver.com/v1/search/shop.json"
    headers = {
        "X-Naver-Client-Id": NAVER_CLIENT_ID,
        "X-Naver-Client-Secret": NAVER_CLIENT_SECRET,
    }
    params = {"query": keyword, "display": max_results}

    try:
        response = requests.get(url, headers=headers, params=params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            products = []
            for item in data.get("items", []):
                products.append(
                    {
                        "title": item.get("title", "")
                        .replace("<b>", "")
                        .replace("</b>", ""),
                        "price": int(item.get("lprice", 0)),
                        "image": item.get("image", ""),
                        "brand": item.get("brand", ""),
                        "mall": item.get("mallName", ""),
                        "link": item.get("link", ""),
                        "category": item.get("category1", ""),
                    }
                )
            return products
        return []
    except Exception as e:
        st.error(f"네이버 쇼핑 검색 실패: {e}")
        return []


def analyze_competitors(products: list) -> dict:
    """경쟁사 분석 - 가격 통계"""
    if not products:
        return {"min": 0, "max": 0, "avg": 0, "count": 0}

    prices = [p["price"] for p in products if p["price"] > 0]
    if not prices:
        return {"min": 0, "max": 0, "avg": 0, "count": 0}

    return {
        "min": min(prices),
        "max": max(prices),
        "avg": sum(prices) // len(prices),
        "count": len(prices),
    }
