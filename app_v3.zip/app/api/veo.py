# ==========================================
# 🎬 Veo 영상 생성 함수
# Vertex AI Pipelines 호환 설계
# ==========================================
import time
from typing import Optional, Callable

from config import VEO_MODEL_ID, GCS_BUCKET_NAME


def generate_marketing_prompt(product: dict, insights: dict) -> str:
    """Veo용 8개 컴포넌트 마케팅 프롬프트 생성 (Google AI 가이드 기반)"""
    hook_text = insights.get("hook", "벌레 싹!")
    style = insights.get("style", "cinematic")
    mood = insights.get("mood", "dramatic")

    # 스타일/분위기 매핑
    style_desc = {
        "cinematic": "cinematic film-like quality with shallow depth of field",
        "commercial": "polished commercial advertisement broadcast quality",
        "horror": "dark suspenseful horror movie aesthetic with tension",
        "documentary": "documentary-style realistic natural footage",
    }.get(style, "cinematic professional quality")

    mood_desc = {
        "dramatic": "dramatic intense high-stakes atmosphere",
        "urgent": "urgent fast-paced action with quick movements",
        "hopeful": "hopeful optimistic uplifting bright feeling",
        "calm": "calm serene peaceful soothing environment",
    }.get(mood, "dramatic impactful atmosphere")

    prompt = f"""
SUBJECT: Professional pest control product "{product.get("name", "")}" with blue packaging and modern design.
A professional pest control solution designed for {product.get("target", "해충")}.

SETTING: Modern Korean home with clean kitchen environment, bright natural lighting.
The scene transitions from a problem state (pest infestation) to a solution state (pest-free clean environment).

ACTION: Dynamic product demonstration sequence:
- Initial: Reveal of pest problem (subtle, not graphic)
- Middle: Product application with satisfying spray effect
- Climax: Pests flee or disappear with visual effect
- Final: Clean, protected home environment with satisfied homeowner

STYLE: {style_desc}. {mood_desc}.
Premium Korean vertical advertisement (9:16), vibrant colors, professional marketing aesthetic.

CAMERA MOVEMENT: 
- Opening: Wide establishing shot of the scene
- Middle: Smooth dolly movement, close-up product shots
- Close: Low-angle hero shot of the protected space
- Final: Wide clean home reveal

COMPOSITION: 
- Product centered with blue glow effect
- Text overlay "{hook_text}" in bold Korean typography
- Before/after visual contrast
- Vertical 9:16 format for mobile shortform

LIGHTING AND MOOD: 
- Cool blue tones transitioning to warm golden light
- Bright key light with soft fill
- Emphasizing product cleanliness and home freshness
- Subtle lens flare during transformation moment

AUDIO ELEMENTS:
- Background: Low suspenseful hum builds tension initially
- SFX: Satisfying spray sound effect during product action
- Transition: Crisp clean "whoosh" sound as scene transforms
- Music: Upbeat Korean advertisement music
- End: Brief triumphant musical sting with confident voiceover tone

NEGATIVE PROMPT: watermarks, text overlays with errors, subtitles, blurry, low quality, unprofessional appearance.
"""
    return prompt.strip()


def generate_video_long_running(
    prompt_text: str,
    logger: Optional[Callable] = None,
    output_gcs_uri: Optional[str] = None,
    duration_seconds: int = 8,
    resolution: str = "720p",
    generate_audio: bool = True,
    number_of_videos: int = 1,
) -> bytes | str:
    """
    Veo로 마케팅 영상 생성 (확장 옵션)

    Args:
        prompt_text: 영상 프롬프트
        logger: 로그 함수 (Streamlit status 또는 print)
        output_gcs_uri: GCS 저장 경로 (없으면 자동 생성)
        duration_seconds: 영상 길이 (8/15/30초)
        resolution: 해상도 (720p/1080p)
        generate_audio: 오디오 생성 여부
        number_of_videos: 생성할 영상 수

    Returns:
        bytes: 영상 데이터 (성공 시)
        str: 상태 메시지 (진행 중 또는 오류)
    """
    try:
        from google import genai
        from google.genai.types import GenerateVideosConfig
        from datetime import datetime as dt

        client = genai.Client()

        # GCS 저장 경로 설정
        if not output_gcs_uri:
            date_str = dt.now().strftime("%Y%m%d")
            output_gcs_uri = f"gs://{GCS_BUCKET_NAME}/videos/{date_str}/"

        if logger:
            logger(
                f"📡 Veo 3.1 API 요청 전송 중... ({duration_seconds}초, {resolution})"
            )

        operation = client.models.generate_videos(
            model=VEO_MODEL_ID,
            prompt=prompt_text,
            config=GenerateVideosConfig(
                aspect_ratio="9:16",
                output_gcs_uri=output_gcs_uri,
                duration_seconds=duration_seconds,
                generate_audio=generate_audio,
                number_of_videos=number_of_videos,
                resolution=resolution,
                negative_prompt="watermarks, text overlays, subtitles, blurry, low quality",
                person_generation="allow_adult",
            ),
        )

        if logger:
            logger("✅ 작업 시작됨")

        # 비동기 폴링 (최대 180초 - 긴 영상 대비)
        max_wait = 180 if duration_seconds > 8 else 120
        waited = 0

        while not operation.done and waited < max_wait:
            time.sleep(10)
            waited += 10
            operation = client.operations.get(operation)
            if logger:
                logger(f"⏳ 생성 중... ({waited}초)")

        if operation.done and operation.result:
            video = operation.result.generated_videos[0]
            video_uri = video.video.uri

            if logger:
                logger(f"🎉 영상 생성 완료!")
                logger(f"📁 GCS 저장: {video_uri}")

            # GCS에서 영상 다운로드
            try:
                from google.cloud import storage as gcs_storage

                gcs_client = gcs_storage.Client()
                path_parts = video_uri.replace("gs://", "").split("/", 1)
                bucket_name = path_parts[0]
                blob_path = path_parts[1] if len(path_parts) > 1 else ""

                bucket = gcs_client.bucket(bucket_name)
                blob = bucket.blob(blob_path)
                video_content = blob.download_as_bytes()
                return video_content
            except Exception as download_error:
                return (
                    f"영상 생성됨 (GCS): {video_uri}\n다운로드 오류: {download_error}"
                )
        else:
            return f"⏳ 영상 생성 진행 중 (백그라운드)\nGCS에서 확인: {output_gcs_uri}"

    except Exception as e:
        return f"시스템 오류: {e}"


def generate_multi_videos(
    product: dict,
    base_hook: str,
    logger: Optional[Callable] = None,
    duration_seconds: int = 8,
) -> list:
    """
    3가지 스타일의 영상 프롬프트 생성 (실제 생성은 선택적)

    Returns:
        list: [{"type": "공포형", "prompt": str, ...}, ...]
    """
    styles = [
        {
            "type": "공포형",
            "style": "horror",
            "mood": "urgent",
            "hook": f"😱 {base_hook}",
        },
        {
            "type": "정보형",
            "style": "commercial",
            "mood": "hopeful",
            "hook": f"💡 {base_hook}",
        },
        {
            "type": "유머형",
            "style": "commercial",
            "mood": "hopeful",
            "hook": f"😂 {base_hook}",
        },
    ]

    results = []
    for s in styles:
        insights = {"hook": s["hook"], "style": s["style"], "mood": s["mood"]}

        prompt = generate_marketing_prompt(product, insights)

        results.append(
            {
                "type": s["type"],
                "hook": s["hook"],
                "prompt": prompt,
                "duration": duration_seconds,
            }
        )

        if logger:
            logger(f"📝 {s['type']} 영상 프롬프트 생성 완료")

    return results
