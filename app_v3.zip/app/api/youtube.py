# ==========================================
# 📺 YouTube API 함수
# ==========================================
import streamlit as st
from googleapiclient.discovery import build
from youtube_transcript_api import YouTubeTranscriptApi

from config import YOUTUBE_API_KEY


def search_youtube_videos(keyword: str, max_results: int = 3) -> list:
    """YouTube 영상 검색"""
    try:
        youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
        request = youtube.search().list(
            part="snippet",
            q=keyword,
            type="video",
            maxResults=max_results,
            order="relevance",
            regionCode="KR",
            relevanceLanguage="ko",
        )
        response = request.execute()
        return [
            {
                "id": item["id"]["videoId"],
                "title": item["snippet"]["title"],
                "description": item["snippet"]["description"],
                "thumbnail": item["snippet"]["thumbnails"]["medium"]["url"],
                "channel": item["snippet"]["channelTitle"],
                "published_at": item["snippet"]["publishedAt"],
            }
            for item in response.get("items", [])
        ]
    except Exception as e:
        st.error(f"유튜브 검색 실패: {e}")
        return []


def get_transcript(video_id: str) -> str | None:
    """YouTube 영상 자막 추출"""
    try:
        transcript = YouTubeTranscriptApi.get_transcript(
            video_id, languages=["ko", "en"]
        )
        return " ".join([t["text"] for t in transcript])
    except Exception:
        return None


def get_video_comments(video_id: str, max_comments: int = 20) -> list:
    """YouTube 영상 댓글 수집 (페인포인트 추출용)"""
    try:
        youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
        request = youtube.commentThreads().list(
            part="snippet",
            videoId=video_id,
            maxResults=max_comments,
            order="relevance",  # 관련성 높은 댓글 우선
            textFormat="plainText",
        )
        response = request.execute()

        comments = []
        for item in response.get("items", []):
            comment = item["snippet"]["topLevelComment"]["snippet"]
            comments.append(
                {
                    "text": comment["textDisplay"],
                    "likes": comment.get("likeCount", 0),
                    "author": comment.get("authorDisplayName", ""),
                    "published_at": comment.get("publishedAt", ""),
                }
            )

        # 좋아요 순으로 정렬
        return sorted(comments, key=lambda x: x["likes"], reverse=True)
    except Exception:
        # 댓글 비활성화 등 오류 시 빈 리스트 반환
        return []


def extract_pain_points(comments: list) -> list:
    """댓글에서 페인포인트 키워드 추출"""
    pain_keywords = [
        "안됨",
        "안돼",
        "효과없",
        "효과 없",
        "별로",
        "실망",
        "냄새",
        "불편",
        "어려",
        "비싸",
        "오래",
        "느리",
        "힘들",
        "짜증",
        "못",
        "안 ",
        "없어",
        "부족",
        "문제",
        "고장",
        "AS",
        "환불",
        "반품",
    ]

    pain_comments = []
    for comment in comments:
        text = comment["text"]
        for keyword in pain_keywords:
            if keyword in text:
                pain_comments.append(
                    {
                        "text": text[:200],  # 최대 200자
                        "keyword": keyword,
                        "likes": comment["likes"],
                    }
                )
                break

    return pain_comments[:10]  # 상위 10개


def extract_gain_points(comments: list) -> list:
    """댓글에서 게인포인트(긍정 피드백) 추출"""
    gain_keywords = [
        "좋아",
        "최고",
        "효과",
        "추천",
        "만족",
        "대박",
        "잘",
        "빠르",
        "확실",
        "깨끗",
        "사라",
        "없어졌",
        "해결",
        "굿",
        "완전",
        "감사",
        "찐",
    ]

    gain_comments = []
    for comment in comments:
        text = comment["text"]
        for keyword in gain_keywords:
            if keyword in text:
                gain_comments.append(
                    {"text": text[:200], "keyword": keyword, "likes": comment["likes"]}
                )
                break

    return gain_comments[:10]


def collect_youtube_data(
    product: dict, max_results: int = 5, include_comments: bool = True
) -> dict:
    """제품 기반 YouTube 데이터 수집 (확장)"""
    # 제품명 기반 검색 키워드 생성
    keywords = [
        product["name"],
        f"{product['target']} 퇴치",
        f"{product['category']} 추천",
    ]

    collected_videos = []
    all_comments = []

    for keyword in keywords[:2]:  # 상위 2개 키워드
        videos = search_youtube_videos(keyword, max_results)
        for v in videos:
            transcript = get_transcript(v["id"])

            # 댓글 수집 (옵션)
            comments = []
            if include_comments:
                comments = get_video_comments(v["id"], max_comments=30)
                all_comments.extend(comments)

            collected_videos.append(
                {
                    "keyword": keyword,
                    "video_id": v["id"],
                    "title": v["title"],
                    "description": v["description"],
                    "transcript": transcript[:2000]
                    if transcript
                    else v["description"][:500],
                    "thumbnail": v.get("thumbnail", ""),
                    "channel": v.get("channel", ""),
                    "comments_count": len(comments),
                }
            )

    # 페인/게인 포인트 분석
    pain_points = extract_pain_points(all_comments) if include_comments else []
    gain_points = extract_gain_points(all_comments) if include_comments else []

    return {
        "product": product,
        "videos": collected_videos,
        "comments_total": len(all_comments),
        "pain_points": pain_points,
        "gain_points": gain_points,
        "top_comments": all_comments[:20] if all_comments else [],
    }
