import streamlit as st
import os
import json
import datetime
import time
import requests
from googleapiclient.discovery import build
from youtube_transcript_api import YouTubeTranscriptApi
from google.cloud import storage
import google.generativeai as genai

# ==========================================
# ⚙️ 설정 (genesis_kr 통합)
# ==========================================
YOUTUBE_API_KEY = "AIzaSyAujUhrll43asWHHNHsRMKv8vR4wN1_F28"
GEMINI_API_KEY = "AIzaSyAujUhrll43asWHHNHsRMKv8vR4wN1_F28"

GOOGLE_CLOUD_PROJECT_ID = "jnu-rise-edu-149"
GCS_BUCKET_NAME = "auto-pipeline-practice"
KEY_FILE = "key.json"
LOCATION = "us-central1"

# 🔐 Vertex AI 환경변수 설정 (genesis_kr와 동일)
os.environ["GOOGLE_CLOUD_PROJECT"] = GOOGLE_CLOUD_PROJECT_ID
os.environ["GOOGLE_CLOUD_LOCATION"] = "global"
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"
if os.path.exists(KEY_FILE):
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = os.path.join(
        os.path.dirname(__file__), KEY_FILE
    )

# 🤖 AI 모델 설정 (genesis_kr 모델)
GEMINI_MODEL_NAME = "gemini-2.5-flash"  # 분석용
GEMINI_IMAGE_MODEL = "gemini-3-pro-image-preview"  # 이미지 생성용 (genesis_kr와 동일)
VEO_MODEL_ID = "veo-3.1-fast-generate-001"  # 영상 생성용 (genesis_kr와 동일)


# 🛒 네이버 쇼핑 API
NAVER_CLIENT_ID = "nvExjvRi7TYhl37jYO62"
NAVER_CLIENT_SECRET = "DJ5GZA3qaq"

# 📦 블루가드 제품 카탈로그 (15개)
BLUEGUARD_PRODUCTS = [
    {
        "name": "벅스델타",
        "category": "해충방제",
        "description": "델타메트린 기반 희석형 광역살충제",
        "target": "모든 해충",
    },
    {
        "name": "벅스델타S",
        "category": "해충방제",
        "description": "델타메트린 기반 스프레이형 즉석 살충제",
        "target": "모든 해충",
    },
    {
        "name": "벅스라인 산제",
        "category": "해충방제",
        "description": "라인 도포형 가루 살충제",
        "target": "보행해충",
    },
    {
        "name": "블루가드 바퀴벌레겔",
        "category": "바퀴벌레",
        "description": "연쇄 살충효과 먹이겔",
        "target": "바퀴벌레",
    },
    {
        "name": "블루가드 좀벌레트랩",
        "category": "트랩",
        "description": "좀벌레 전문 끈끈이 트랩",
        "target": "좀벌레",
    },
    {
        "name": "블루가드 화랑곡나방트랩",
        "category": "트랩",
        "description": "페로몬 유인 끈끈이 트랩",
        "target": "나방",
    },
    {
        "name": "뱀이싹",
        "category": "기피제",
        "description": "천연유래물질 성분 뱀 기피제",
        "target": "뱀",
    },
    {
        "name": "쥐싹킬",
        "category": "쥐약",
        "description": "나가서 말라죽는 알약형 쥐약",
        "target": "쥐",
    },
    {
        "name": "싹보내 퇴치기",
        "category": "퇴치기",
        "description": "지진파 원리 두더지/뱀 퇴치기",
        "target": "두더지/뱀",
    },
    {
        "name": "싹보내G 퇴치기",
        "category": "퇴치기",
        "description": "3중 퇴치 야생동물용",
        "target": "야생동물",
    },
    {
        "name": "모기싹",
        "category": "해충방제",
        "description": "모기 퇴치 전문 제품",
        "target": "모기",
    },
    {
        "name": "개미싹",
        "category": "해충방제",
        "description": "개미 퇴치 전문 제품",
        "target": "개미",
    },
    {
        "name": "파리싹",
        "category": "해충방제",
        "description": "파리 퇴치 전문 제품",
        "target": "파리",
    },
    {
        "name": "냄새싹",
        "category": "탈취/방향",
        "description": "강력 탈취 제품",
        "target": "악취",
    },
    {
        "name": "블루가드올인원",
        "category": "종합",
        "description": "다기능 통합 솔루션",
        "target": "다용도",
    },
]

if os.path.exists(KEY_FILE):
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = KEY_FILE

genai.configure(api_key=GEMINI_API_KEY)


# ==========================================
# 🎨 Neobrutalism Light Theme CSS (개선버전)
# - 컴팩트 레이아웃 (한 화면에 표시)
# - Expander 텍스트 겹침 수정
# ==========================================
def inject_neobrutalism_css():
    st.markdown(
        """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap');
    
    /* === 네오브루탈리즘 색상 팔레트 === */
    :root {
        --bg-cream: #FFFDF7;
        --bg-yellow: #FEF3C7;
        --bg-mint: #D1FAE5;
        --bg-pink: #FCE7F3;
        --bg-blue: #DBEAFE;
        --bg-purple: #EDE9FE;
        --accent-red: #FF6B6B;
        --accent-blue: #4F46E5;
        --accent-green: #10B981;
        --accent-yellow: #FBBF24;
        --accent-purple: #8B5CF6;
        --text-black: #1A1A1A;
        --text-gray: #525252;
        --border-black: #1A1A1A;
    }
    
    /* 기본 폰트 - Material Icons 제외 */
    *:not([data-testid="stIconMaterial"]):not(.material-icons):not([class*="icon"]) {
        font-family: 'Space Grotesk', -apple-system, sans-serif !important;
    }
    
    /* Material Icons 복원 */
    [data-testid="stIconMaterial"],
    .material-icons,
    span[translate="no"][class*="exvv1vr0"] {
        font-family: 'Material Symbols Rounded', 'Material Icons' !important;
    }
    
    /* 앱 배경 */
    .stApp {
        background-color: var(--bg-cream) !important;
    }
    
    /* ===== 컴팩트 레이아웃 ===== */
    .block-container {
        padding-top: 1rem !important;
        padding-bottom: 1rem !important;
        max-width: 1200px !important;
    }
    
    /* 헤더 컴팩트화 */
    .neo-header {
        text-align: center;
        padding: 16px 20px;
        margin-bottom: 16px;
    }
    
    .neo-title {
        font-size: 2rem;
        font-weight: 700;
        color: var(--text-black) !important;
        margin-bottom: 4px;
        letter-spacing: -0.02em;
    }
    
    .neo-title-accent {
        display: inline-block;
        background: var(--accent-yellow);
        padding: 2px 12px;
        border: 2px solid var(--border-black);
        box-shadow: 3px 3px 0 var(--border-black);
        transform: rotate(-1deg);
    }
    
    .neo-subtitle {
        font-size: 0.95rem;
        color: var(--text-gray) !important;
        font-weight: 500;
        margin-top: 8px;
    }
    
    /* 텍스트 색상 */
    h1, h2, h3, h4, h5, h6 {
        color: var(--text-black) !important;
        font-weight: 700 !important;
        margin-top: 0.5rem !important;
        margin-bottom: 0.5rem !important;
    }
    
    h3 { font-size: 1.1rem !important; }
    
    p, span, label, div {
        color: var(--text-gray) !important;
    }
    
    /* 사이드바 */
    section[data-testid="stSidebar"] {
        background: var(--bg-yellow) !important;
        border-right: 3px solid var(--border-black) !important;
        width: 280px !important;
    }
    
    section[data-testid="stSidebar"] > div {
        padding-top: 1rem !important;
    }
    
    /* 네오브루탈리즘 카드 - 컴팩트 */
    .neo-card {
        background: white;
        border: 2px solid var(--border-black);
        border-radius: 0;
        padding: 12px;
        box-shadow: 4px 4px 0 var(--border-black);
        transition: all 0.2s ease;
        text-align: center;
        min-height: 90px;
    }
    
    .neo-card:hover {
        transform: translate(-2px, -2px);
        box-shadow: 6px 6px 0 var(--border-black);
    }
    
    .neo-card.pink { background: var(--bg-pink); }
    .neo-card.blue { background: var(--bg-blue); }
    .neo-card.mint { background: var(--bg-mint); }
    .neo-card.purple { background: var(--bg-purple); }
    .neo-card.yellow { background: var(--bg-yellow); }
    
    .neo-metric-icon {
        font-size: 1.4rem;
        margin-bottom: 4px;
    }
    
    .neo-metric-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--text-black) !important;
        margin-bottom: 2px;
    }
    
    .neo-metric-label {
        font-size: 0.7rem;
        color: var(--text-gray) !important;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    /* 프로그레스 바 */
    .neo-progress {
        background: white;
        border: 2px solid var(--border-black);
        padding: 12px;
        box-shadow: 3px 3px 0 var(--border-black);
        margin: 8px 0;
    }
    
    .neo-progress-track {
        background: var(--bg-cream);
        border: 2px solid var(--border-black);
        height: 16px;
        overflow: hidden;
    }
    
    .neo-progress-fill {
        height: 100%;
        background: var(--accent-green);
        transition: width 0.5s ease;
    }
    
    .neo-progress-text {
        text-align: center;
        margin-top: 8px;
        font-size: 0.9rem;
        font-weight: 700;
        color: var(--text-black) !important;
    }
    
    /* 스텝 아이템 - 컴팩트 */
    .neo-step {
        display: flex;
        align-items: center;
        padding: 8px 12px;
        margin: 4px 0;
        background: white;
        border: 2px solid var(--border-black);
        box-shadow: 2px 2px 0 var(--border-black);
        transition: all 0.2s ease;
    }
    
    .neo-step.complete {
        background: var(--bg-mint);
    }
    
    .neo-step.active {
        background: var(--bg-blue);
    }
    
    .neo-step-icon {
        font-size: 1rem;
        margin-right: 10px;
        font-weight: 700;
    }
    
    .neo-step-label {
        font-weight: 600;
        color: var(--text-black) !important;
        font-size: 0.85rem;
    }
    
    /* 버튼 */
    .stButton > button {
        background: var(--accent-red) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        color: white !important;
        font-weight: 700 !important;
        padding: 10px 20px !important;
        font-size: 0.9rem !important;
        box-shadow: 3px 3px 0 var(--border-black) !important;
        transition: all 0.2s ease !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
    }
    
    .stButton > button:hover {
        transform: translate(-2px, -2px) !important;
        box-shadow: 5px 5px 0 var(--border-black) !important;
    }
    
    .stButton > button:active {
        transform: translate(2px, 2px) !important;
        box-shadow: 1px 1px 0 var(--border-black) !important;
    }
    
    /* 입력 필드 */
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea,
    .stNumberInput > div > div > input {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        color: var(--text-black) !important;
        padding: 8px 12px !important;
        font-weight: 500 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    /* Selectbox 스타일 수정 */
    .stSelectbox > div > div {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
        min-height: 42px !important;
    }
    
    /* Selectbox 선택된 값 텍스트 */
    .stSelectbox [data-baseweb="select"] > div {
        background: white !important;
        min-height: 42px !important;
    }
    
    .stSelectbox [data-baseweb="select"] > div > div {
        color: var(--text-black) !important;
        font-weight: 500 !important;
        overflow: visible !important;
    }
    
    /* Selectbox 내부 value div */
    .stSelectbox [data-baseweb="select"] [value] {
        color: var(--text-black) !important;
        font-size: 0.9rem !important;
        font-weight: 500 !important;
        white-space: nowrap !important;
        overflow: visible !important;
    }
    
    .stTextInput > div > div > input:focus,
    .stTextArea > div > div > textarea:focus {
        border-color: var(--accent-blue) !important;
        box-shadow: 2px 2px 0 var(--accent-blue) !important;
    }
    
    /* 폼 */
    [data-testid="stForm"] {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        padding: 16px !important;
        box-shadow: 4px 4px 0 var(--border-black) !important;
    }
    
    /* ===== 탭 스타일 (재설계) ===== */
    /* 1. 탭 컨테이너 초기화 */
    .stTabs {
        position: relative;
    }

    /* 2. 탭 리스트 - 네오브루탈리즘 스타일 */
    .stTabs [data-baseweb="tab-list"] {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        box-shadow: 3px 3px 0 var(--border-black) !important;
        padding: 0 !important;
        gap: 0 !important;
        display: flex !important;
        flex-direction: row !important;
        align-items: stretch !important;
        justify-content: flex-start !important;
        border-radius: 0 !important;
    }

    /* 3. 개별 탭 버튼 */
    .stTabs [data-baseweb="tab"] {
        background: white !important;
        border-right: 2px solid var(--border-black) !important;
        border-left: none !important;
        border-top: none !important;
        border-bottom: none !important;
        color: var(--text-black) !important;
        font-weight: 600 !important;
        padding: 10px 16px !important;
        border-radius: 0 !important;
        font-size: 0.85rem !important;
        height: auto !important;
        min-height: 44px !important;
    }

    /* 4. 마지막 탭 오른쪽 테두리 제거 */
    .stTabs [data-baseweb="tab"]:last-child {
        border-right: none !important;
    }

    /* 5. 선택된 탭 강조 */
    .stTabs [data-baseweb="tab"][aria-selected="true"] {
        background: var(--accent-yellow) !important;
        color: var(--text-black) !important;
        font-weight: 700 !important;
    }

    /* 6. 탭 호버 효과 */
    .stTabs [data-baseweb="tab"]:hover {
        background: var(--bg-cream) !important;
    }

    .stTabs [data-baseweb="tab"][aria-selected="true"]:hover {
        background: var(--accent-yellow) !important;
    }

    /* 7. 탭 패널 (내용 영역) */
    .stTabs [data-baseweb="tab-panel"] {
        padding-top: 1rem !important;
    }

    /* 8. Streamlit 동적 클래스 처리 */
    .stTabs button[data-baseweb="tab"] > div {
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    
    /* ===== Expander 수정 (텍스트 겹침 해결) ===== */
    .streamlit-expanderHeader {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
        padding: 10px 16px !important;
        font-size: 0.85rem !important;
    }

    .streamlit-expanderHeader p {
        margin: 0 !important;
        padding-left: 8px !important;
        font-weight: 600 !important;
        color: var(--text-black) !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
    }

    /* Expander 아이콘과 텍스트 간격 */
    .streamlit-expanderHeader svg {
        margin-right: 8px !important;
        flex-shrink: 0 !important;
    }

    .streamlit-expanderContent {
        background: var(--bg-cream) !important;
        border: 2px solid var(--border-black) !important;
        border-top: none !important;
        border-radius: 0 !important;
        padding: 12px !important;
        font-size: 0.85rem !important;
    }
    
    /* 알림 메시지 */
    .stSuccess, .stInfo, .stWarning, .stError {
        padding: 10px 14px !important;
        font-size: 0.85rem !important;
    }
    
    .stSuccess {
        background: var(--bg-mint) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    .stInfo {
        background: var(--bg-blue) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    .stWarning {
        background: var(--bg-yellow) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    .stError {
        background: var(--bg-pink) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    /* 비디오 */
    video {
        border: 2px solid var(--border-black) !important;
        box-shadow: 4px 4px 0 var(--border-black) !important;
    }
    
    /* 코드 블록 */
    .stCodeBlock {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
        font-size: 0.8rem !important;
    }
    
    /* 구분선 */
    hr {
        border: 1px solid var(--border-black) !important;
        margin: 12px 0 !important;
    }
    
    /* 푸터 */
    .neo-footer {
        text-align: center;
        padding: 16px;
        margin-top: 12px;
    }
    
    .neo-footer-badge {
        display: inline-block;
        background: var(--accent-purple);
        color: white !important;
        padding: 6px 16px;
        border: 2px solid var(--border-black);
        box-shadow: 3px 3px 0 var(--border-black);
        font-weight: 700;
        font-size: 0.8rem;
    }
    
    /* Status 컴포넌트 컴팩트화 */
    [data-testid="stStatusWidget"] {
        font-size: 0.85rem !important;
    }
    
    /* Caption 스타일 */
    .stCaption {
        font-size: 0.8rem !important;
        margin-bottom: 8px !important;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )


# --- [핵심 함수들] ---
def search_youtube_videos(keyword, max_results=3):
    try:
        youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)
        request = youtube.search().list(
            q=keyword,
            part="snippet",
            type="video",
            maxResults=max_results,
            order="date",
        )
        response = request.execute()
        return [
            {
                "id": i["id"]["videoId"],
                "title": i["snippet"]["title"],
                "description": i["snippet"]["description"],
            }
            for i in response["items"]
        ]
    except Exception as e:
        st.error(f"유튜브 검색 실패: {e}")
        return []


def get_transcript(video_id):
    try:
        transcript = YouTubeTranscriptApi.get_transcript(
            video_id, languages=["ko", "en"]
        )
        return " ".join([t["text"] for t in transcript])
    except Exception:
        return None


def upload_to_gcs(data, bucket_name, filename, content_type="application/json"):
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(filename)
        if content_type == "application/json":
            blob.upload_from_string(
                json.dumps(data, ensure_ascii=False, indent=2),
                content_type=content_type,
            )
        else:
            blob.upload_from_string(data, content_type=content_type)
        return True
    except Exception as e:
        st.error(f"GCS 업로드 에러: {e}")
        return False


def read_from_gcs(bucket_name, filename):
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(filename)
        return blob.download_as_text()
    except Exception:
        return None


def analyze_with_gemini(json_text):
    """Gemini로 마케팅 분석 및 영상 프롬프트 생성 (genesis_kr 방식)"""
    try:
        from google import genai
        from google.genai import types

        client = genai.Client()

        prompt = f"""
[역할]: AI 비디오 디렉터
[데이터]: {json_text}
[요청]: 
1. Veo로 영상을 만들 영어 프롬프트를 작성해.
2. 조건: 오직 '영어 프롬프트 문장'만 출력해.
3. 스타일: Cinematic, 4k quality, photorealistic.
"""

        # genesis_kr와 동일하게 gemini-3-pro-preview 사용
        response = client.models.generate_content(
            model="gemini-3-pro-preview",
            contents=prompt,
            config=types.GenerateContentConfig(
                thinking_config=types.ThinkingConfig(
                    thinking_level=types.ThinkingLevel.LOW
                )
            ),
        )
        return response.text
    except Exception as e:
        return f"Gemini 오류: {e}"


def generate_video_long_running(prompt_text, status_container):
    """Veo로 마케팅 영상 생성 (genesis_kr 방식)"""
    try:
        from google import genai
        from google.genai.types import GenerateVideosConfig
        from datetime import datetime as dt

        client = genai.Client()

        # GCS 저장 경로 설정
        date_str = dt.now().strftime("%Y%m%d")
        output_gcs_uri = f"gs://{GCS_BUCKET_NAME}/streamlit_videos/{date_str}/"

        status_container.write("📡 Veo 3.1 API 요청 전송 중...")

        # genesis_kr와 동일하게 Veo 3.1 Fast 사용
        operation = client.models.generate_videos(
            model=VEO_MODEL_ID,  # veo-3.1-fast-generate-001
            prompt=prompt_text,
            config=GenerateVideosConfig(
                aspect_ratio="9:16",  # 숏폼용 세로형
                output_gcs_uri=output_gcs_uri,
                duration_seconds=8,
                generate_audio=True,
                number_of_videos=1,
                resolution="720p",
                negative_prompt="watermarks, text overlays, subtitles, blurry, low quality",
                person_generation="allow_adult",
            ),
        )

        status_container.write("✅ 작업 시작됨")
        progress_bar = status_container.progress(0)

        # 비동기 폴링 (최대 120초)
        max_wait = 120
        waited = 0

        while not operation.done and waited < max_wait:
            time.sleep(10)
            waited += 10
            operation = client.operations.get(operation)
            progress_bar.progress(min(int(waited / max_wait * 100), 95))
            status_container.write(f"⏳ 생성 중... ({waited}초)")

        if operation.done and operation.result:
            video = operation.result.generated_videos[0]
            video_uri = video.video.uri
            progress_bar.progress(100)
            status_container.write(f"🎉 영상 생성 완료!")
            status_container.write(f"📁 GCS 저장: {video_uri}")

            # GCS에서 영상 다운로드
            try:
                from google.cloud import storage as gcs_storage

                gcs_client = gcs_storage.Client()

                # gs://bucket/path 형식 파싱
                path_parts = video_uri.replace("gs://", "").split("/", 1)
                bucket_name = path_parts[0]
                blob_path = path_parts[1] if len(path_parts) > 1 else ""

                bucket = gcs_client.bucket(bucket_name)
                blob = bucket.blob(blob_path)
                video_content = blob.download_as_bytes()
                return video_content
            except Exception as download_error:
                return (
                    f"영상 생성됨 (GCS): {video_uri}\n다운로드 오류: {download_error}"
                )
        else:
            return f"⏳ 영상 생성 진행 중 (백그라운드)\nGCS에서 확인: {output_gcs_uri}"

    except Exception as e:
        return f"시스템 오류: {e}"


# --- [genesis_kr 추가 함수들] ---
def search_naver_shopping(keyword, max_results=10):
    """네이버 쇼핑 API로 상품 검색"""
    if not NAVER_CLIENT_ID or not NAVER_CLIENT_SECRET:
        return []

    url = "https://openapi.naver.com/v1/search/shop.json"
    headers = {
        "X-Naver-Client-Id": NAVER_CLIENT_ID,
        "X-Naver-Client-Secret": NAVER_CLIENT_SECRET,
    }
    params = {"query": keyword, "display": max_results}

    try:
        response = requests.get(url, headers=headers, params=params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            products = []
            for item in data.get("items", []):
                products.append(
                    {
                        "title": item.get("title", "")
                        .replace("<b>", "")
                        .replace("</b>", ""),
                        "price": int(item.get("lprice", 0)),
                        "image": item.get("image", ""),
                        "brand": item.get("brand", ""),
                        "mall": item.get("mallName", ""),
                        "link": item.get("link", ""),
                    }
                )
            return products
        return []
    except Exception as e:
        st.error(f"네이버 쇼핑 검색 실패: {e}")
        return []


def analyze_sentiment(comments):
    """댓글 감성 분석 (긍정/부정 키워드 기반)"""
    positive_words = [
        "좋아요",
        "최고",
        "감사",
        "효과",
        "추천",
        "대박",
        "굿",
        "완벽",
        "만족",
        "짱",
    ]
    negative_words = [
        "별로",
        "안돼",
        "실패",
        "환불",
        "짜증",
        "낭비",
        "사기",
        "후회",
        "비추",
        "실망",
    ]

    positive_count = 0
    negative_count = 0

    for comment in comments:
        for word in positive_words:
            if word in comment:
                positive_count += 1
        for word in negative_words:
            if word in comment:
                negative_count += 1

    total = positive_count + negative_count
    if total > 0:
        score = (positive_count - negative_count) / total
        if score > 0.2:
            return {
                "sentiment": "긍정적 😊",
                "score": score,
                "positive": positive_count,
                "negative": negative_count,
            }
        elif score < -0.2:
            return {
                "sentiment": "부정적 😞",
                "score": score,
                "positive": positive_count,
                "negative": negative_count,
            }
    return {
        "sentiment": "중립 😐",
        "score": 0,
        "positive": positive_count,
        "negative": negative_count,
    }


def generate_thumbnail(product_name, hook_text, status_container):
    """Gemini로 마케팅 썸네일 이미지 생성 (genesis_kr 방식)"""
    try:
        # genesis_kr와 동일하게 google.genai.Client 사용
        from google import genai
        from google.genai.types import GenerateContentConfig, Modality

        client = genai.Client()

        prompt = f"""
Create a HIGH IMPACT vertical thumbnail for Korean pest control shortform content.

PRODUCT: {product_name}
TEXT: "{hook_text}" in GIANT bold yellow font with black outline
STYLE: Dramatic blue gradient, before/after split, professional marketing
ASPECT: 9:16 (vertical shortform)
NO watermarks, clean design
"""

        status_container.write(f"🖼️ 썸네일 생성 중: {product_name}")

        # 핵심: response_modalities 설정으로 이미지 생성
        response = client.models.generate_content(
            model=GEMINI_IMAGE_MODEL,
            contents=prompt,
            config=GenerateContentConfig(
                response_modalities=[Modality.TEXT, Modality.IMAGE],
            ),
        )

        # 이미지가 포함된 응답 처리
        if response.candidates and response.candidates[0].content.parts:
            for part in response.candidates[0].content.parts:
                if part.inline_data:
                    import base64

                    img_data = part.inline_data.data
                    if isinstance(img_data, str):
                        img_data = base64.b64decode(img_data)
                    status_container.write(
                        f"✅ 이미지 생성 완료 ({len(img_data):,} bytes)"
                    )
                    return img_data

        # 텍스트 응답만 있는 경우
        return response.text if hasattr(response, "text") else "이미지 생성 실패"

    except Exception as e:
        return f"썸네일 생성 오류: {e}"


def generate_marketing_prompt(product, insights):
    """Veo용 8개 컴포넌트 마케팅 프롬프트 생성"""
    hook_text = insights.get("hook", "벌레 싹!")

    prompt = f"""
Subject: Professional pest control product "{product["name"]}" with blue packaging and modern design.

Setting: Modern Korean home with clean kitchen environment, bright natural lighting, before/after transformation scene.

Action: Dynamic product demonstration - spray application, pest elimination effect, satisfied homeowner reaction.

Style: Premium Korean vertical advertisement (9:16), cinematic quality, vibrant colors, professional marketing aesthetic.

Camera: Smooth dolly movement, close-up product shots transitioning to wide clean home reveal.

Composition: Product centered with blue glow effect, text overlay "{hook_text}" in bold Korean typography.

Lighting: Bright key light with soft fill, emphasizing product cleanliness and home freshness.

Audio: Upbeat Korean advertisement music, satisfying spray sound effects, confident voiceover tone.

Negative prompt: No watermarks, no poor lighting, no unprofessional appearance, no text errors.
"""
    return prompt


# --- [통합 파이프라인 함수들] ---
def collect_all_data(product, youtube_count=5, naver_count=10, status_container=None):
    """YouTube + 네이버 데이터 통합 수집"""
    result = {
        "product": product,
        "youtube_data": [],
        "naver_data": [],
        "collected_at": datetime.datetime.now().isoformat(),
    }

    # 검색 키워드 자동 생성
    keywords = [
        product["name"],
        f"{product['target']} 퇴치",
        f"{product['category']} 추천",
    ]

    if status_container:
        status_container.write(f"🔍 검색 키워드: {', '.join(keywords)}")

    # 1. YouTube 데이터 수집
    if status_container:
        status_container.write("📺 YouTube 데이터 수집 중...")

    for keyword in keywords[:2]:  # 상위 2개 키워드로 검색
        videos = search_youtube_videos(keyword, youtube_count)
        for v in videos:
            transcript = get_transcript(v["id"])
            result["youtube_data"].append(
                {
                    "keyword": keyword,
                    "title": v["title"],
                    "video_id": v["id"],
                    "description": v["description"],
                    "transcript": transcript[:2000]
                    if transcript
                    else v["description"][:500],
                }
            )

    if status_container:
        status_container.write(f"✅ YouTube: {len(result['youtube_data'])}개 영상 수집")

    # 2. 네이버 쇼핑 데이터 수집
    if status_container:
        status_container.write("🛒 네이버 쇼핑 데이터 수집 중...")

    naver_products = search_naver_shopping(product["name"], naver_count)
    result["naver_data"] = naver_products

    if status_container:
        status_container.write(f"✅ 네이버: {len(result['naver_data'])}개 상품 수집")

    return result


def generate_marketing_strategy(collected_data, status_container=None):
    """AI 기반 종합 마케팅 전략 생성"""
    try:
        from google import genai
        from google.genai import types

        client = genai.Client()

        # 수집된 데이터 요약
        product = collected_data["product"]
        youtube_summary = "\n".join(
            [
                f"- {d['title']}: {d['transcript'][:300]}..."
                for d in collected_data["youtube_data"][:3]
            ]
        )

        naver_summary = "\n".join(
            [
                f"- {d['title']}: {d['price']:,}원 ({d['mall']})"
                for d in collected_data["naver_data"][:5]
            ]
        )

        prompt = f"""
[역할]: 전문 마케팅 전략가 및 숏폼 콘텐츠 기획자
[제품]: {product["name"]} - {product["description"]} (타겟: {product["target"]})

[수집된 YouTube 리뷰 데이터]:
{youtube_summary}

[경쟁사 네이버 쇼핑 데이터]:
{naver_summary}

[요청]: 다음 항목을 JSON 형식으로 출력해주세요:

{{
    "target_persona": {{
        "age": "주요 타겟 연령대",
        "pain_points": ["고객의 고통 포인트 3가지"],
        "desires": ["고객이 원하는 것 3가지"]
    }},
    "hooking_points": [
        {{"type": "공포형", "hook": "후킹 문구", "explanation": "왜 효과적인지"}},
        {{"type": "정보형", "hook": "후킹 문구", "explanation": "왜 효과적인지"}},
        {{"type": "유머형", "hook": "후킹 문구", "explanation": "왜 효과적인지"}}
    ],
    "shortform_scenarios": [
        {{
            "title": "시나리오 제목",
            "type": "공포형/정보형/유머형",
            "script": "8초 영상 스크립트 (씬별 설명)",
            "thumbnail_text": "썸네일 텍스트"
        }}
    ],
    "sns_copies": {{
        "instagram": "인스타그램용 캡션 (해시태그 포함)",
        "youtube_shorts": "유튜브 쇼츠 제목",
        "tiktok": "틱톡용 캡션"
    }},
    "video_prompt": "Veo 영상 생성용 영어 프롬프트 (cinematic, 4k quality, 9:16 vertical)",
    "thumbnail_prompt": "썸네일 이미지 생성용 영어 프롬프트"
}}

중요: 반드시 유효한 JSON만 출력하세요. 설명이나 마크다운 없이 순수 JSON만 출력합니다.
"""

        if status_container:
            status_container.write("🧠 Gemini AI 분석 중...")

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
            ),
        )

        # JSON 파싱
        strategy_text = response.text.strip()
        # JSON 블록 추출 (```json ... ``` 형식 처리)
        if "```json" in strategy_text:
            strategy_text = strategy_text.split("```json")[1].split("```")[0]
        elif "```" in strategy_text:
            strategy_text = strategy_text.split("```")[1].split("```")[0]

        strategy = json.loads(strategy_text)

        if status_container:
            status_container.write("✅ 마케팅 전략 생성 완료!")

        return strategy

    except Exception as e:
        return {"error": str(e)}


def generate_all_content(strategy, product, status_container=None):
    """마케팅 전략 기반 콘텐츠 일괄 생성"""
    results = {
        "thumbnails": [],
        "video": None,
        "copies": strategy.get("sns_copies", {}),
    }

    # 1. 썸네일 생성 (최고 후킹 포인트 사용)
    if status_container:
        status_container.write("🖼️ 썸네일 생성 중...")

    best_hook = strategy.get("hooking_points", [{}])[0]
    hook_text = best_hook.get("hook", "벌레 싹!")

    thumbnail_result = generate_thumbnail(product["name"], hook_text, status_container)
    if isinstance(thumbnail_result, bytes):
        results["thumbnails"].append(
            {
                "type": best_hook.get("type", "기본"),
                "hook": hook_text,
                "data": thumbnail_result,
            }
        )

    # 2. 영상 생성
    if status_container:
        status_container.write("🎬 숏폼 영상 생성 중...")

    video_prompt = strategy.get("video_prompt", "")
    if not video_prompt:
        video_prompt = generate_marketing_prompt(product, {"hook": hook_text})

    video_result = generate_video_long_running(video_prompt, status_container)
    if isinstance(video_result, bytes):
        results["video"] = video_result

    return results


st.set_page_config(
    page_title="제네시스 AI 스튜디오",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_neobrutalism_css()

# 세션 상태
if "step1_done" not in st.session_state:
    st.session_state.step1_done = False
if "step2_done" not in st.session_state:
    st.session_state.step2_done = False
if "step3_done" not in st.session_state:
    st.session_state.step3_done = False
if "collected_data" not in st.session_state:
    st.session_state.collected_data = None
if "generated_prompt" not in st.session_state:
    st.session_state.generated_prompt = None
if "video_path" not in st.session_state:
    st.session_state.video_path = None
# genesis_kr 추가 상태
if "naver_data" not in st.session_state:
    st.session_state.naver_data = None
if "selected_product" not in st.session_state:
    st.session_state.selected_product = BLUEGUARD_PRODUCTS[0]
if "thumbnail_data" not in st.session_state:
    st.session_state.thumbnail_data = None
if "sentiment_result" not in st.session_state:
    st.session_state.sentiment_result = None

# 🚀 통합 파이프라인 상태
if "pipeline_running" not in st.session_state:
    st.session_state.pipeline_running = False
if "pipeline_step" not in st.session_state:
    st.session_state.pipeline_step = 0
if "pipeline_collected_data" not in st.session_state:
    st.session_state.pipeline_collected_data = None
if "pipeline_strategy" not in st.session_state:
    st.session_state.pipeline_strategy = None
if "pipeline_content" not in st.session_state:
    st.session_state.pipeline_content = None


# 진행률 계산
completed_steps = sum(
    [
        st.session_state.step1_done,
        st.session_state.step2_done,
        st.session_state.step3_done,
    ]
)
progress_percent = int(completed_steps / 3 * 100)

# --- 사이드바 ---
with st.sidebar:
    st.markdown("### 🎬 제네시스 AI")
    st.caption("YouTube → AI → Video")
    st.divider()

    # 📦 블루가드 제품 선택
    st.markdown("##### 📦 제품 선택")
    product_names = [p["name"] for p in BLUEGUARD_PRODUCTS]
    selected_idx = st.selectbox(
        "블루가드 제품",
        range(len(product_names)),
        format_func=lambda x: f"{BLUEGUARD_PRODUCTS[x]['name']} ({BLUEGUARD_PRODUCTS[x]['category']})",
        label_visibility="collapsed",
    )
    st.session_state.selected_product = BLUEGUARD_PRODUCTS[selected_idx]

    # 선택된 제품 정보 표시
    product = st.session_state.selected_product
    st.markdown(
        f"""
    <div class="neo-card yellow" style="padding: 8px; min-height: auto;">
        <div style="font-size: 0.8rem; color: var(--text-black) !important;">
            <strong>{product["name"]}</strong><br>
            🎯 {product["target"]}
        </div>
    </div>
    """,
        unsafe_allow_html=True,
    )

    st.divider()

    # 진행률 바
    st.markdown("##### 📊 진행률")
    st.markdown(
        f"""
    <div class="neo-progress">
        <div class="neo-progress-track">
            <div class="neo-progress-fill" style="width: {progress_percent}%;"></div>
        </div>
        <div class="neo-progress-text">{progress_percent}%</div>
    </div>
    """,
        unsafe_allow_html=True,
    )

    st.divider()

    # 스텝 상태
    st.markdown("##### 🔄 단계")
    steps_data = [
        (
            "01",
            "데이터 수집",
            st.session_state.step1_done,
            not st.session_state.step1_done,
        ),
        (
            "02",
            "AI 분석",
            st.session_state.step2_done,
            st.session_state.step1_done and not st.session_state.step2_done,
        ),
        (
            "03",
            "콘텐츠 생성",
            st.session_state.step3_done,
            st.session_state.step2_done and not st.session_state.step3_done,
        ),
    ]

    for num, label, done, is_active in steps_data:
        if done:
            status_class = "complete"
            icon = "✅"
        elif is_active:
            status_class = "active"
            icon = "▶️"
        else:
            status_class = ""
            icon = num

        st.markdown(
            f"""
        <div class="neo-step {status_class}">
            <span class="neo-step-icon">{icon}</span>
            <span class="neo-step-label">{label}</span>
        </div>
        """,
            unsafe_allow_html=True,
        )


# --- 메인 헤더 ---
st.markdown(
    """
<div class="neo-header">
    <h1 class="neo-title">
        <span class="neo-title-accent">🎬 제네시스</span> AI 스튜디오
    </h1>
    <p class="neo-subtitle">YouTube 콘텐츠 분석 → AI 영상 자동 생성</p>
</div>
""",
    unsafe_allow_html=True,
)

# --- 메트릭 카드 (한 줄로 컴팩트하게) ---
collected_count = (
    len(st.session_state.collected_data) if st.session_state.collected_data else 0
)
prompt_status = "완료" if st.session_state.step2_done else "대기"
render_status = "완료" if st.session_state.step3_done else "대기"

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown(
        f"""
    <div class="neo-card pink">
        <div class="neo-metric-icon">📹</div>
        <div class="neo-metric-value">{collected_count}</div>
        <div class="neo-metric-label">수집 영상</div>
    </div>
    """,
        unsafe_allow_html=True,
    )

with col2:
    st.markdown(
        f"""
    <div class="neo-card blue">
        <div class="neo-metric-icon">🧠</div>
        <div class="neo-metric-value">{prompt_status}</div>
        <div class="neo-metric-label">프롬프트</div>
    </div>
    """,
        unsafe_allow_html=True,
    )

with col3:
    st.markdown(
        f"""
    <div class="neo-card mint">
        <div class="neo-metric-icon">🎬</div>
        <div class="neo-metric-value">{render_status}</div>
        <div class="neo-metric-label">렌더링</div>
    </div>
    """,
        unsafe_allow_html=True,
    )

with col4:
    st.markdown(
        f"""
    <div class="neo-card purple">
        <div class="neo-metric-icon">📊</div>
        <div class="neo-metric-value">{progress_percent}%</div>
        <div class="neo-metric-label">진행률</div>
    </div>
    """,
        unsafe_allow_html=True,
    )

# --- 탭 인터페이스 (6개 탭 - 자동화 탭 추가) ---
tab0, tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["🚀 자동화", "📰 YouTube", "🛒 네이버", "🧠 AI 분석", "🖼️ 썸네일", "🎬 영상"]
)

# --- 탭 0: 통합 자동화 파이프라인 ---
with tab0:
    st.markdown("##### 🚀 블루가드 마케팅 자동화 파이프라인")

    product = st.session_state.selected_product
    st.info(
        f"📦 선택된 제품: **{product['name']}** ({product['category']}) - 타겟: {product['target']}"
    )

    # 설정 영역
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**🔍 데이터 수집 설정**")
        youtube_count = st.slider("YouTube 영상 수", 1, 10, 3)
        naver_count = st.slider("네이버 상품 수", 5, 30, 10)

    with col2:
        st.markdown("**🎯 생성할 콘텐츠**")
        gen_strategy = st.checkbox("마케팅 전략 리포트", value=True)
        gen_thumbnail = st.checkbox("썸네일 이미지", value=True)
        gen_video = st.checkbox("숏폼 영상 (8초)", value=True)

    st.divider()

    # 파이프라인 실행 버튼
    if st.button("🚀 전체 파이프라인 실행", use_container_width=True, type="primary"):
        with st.status("🔄 파이프라인 실행 중...", expanded=True) as status:
            try:
                # Step 1: 데이터 수집
                st.session_state.pipeline_step = 1
                status.write("### Step 1/4: 📊 데이터 수집")
                collected = collect_all_data(
                    product,
                    youtube_count=youtube_count,
                    naver_count=naver_count,
                    status_container=status,
                )
                st.session_state.pipeline_collected_data = collected

                # GCS 저장
                upload_to_gcs(
                    collected,
                    GCS_BUCKET_NAME,
                    f"pipeline/collected_{datetime.date.today()}.json",
                )
                status.write("✅ Step 1 완료: 데이터 수집 완료!")

                # Step 2: AI 분석 및 마케팅 전략 생성
                if gen_strategy:
                    st.session_state.pipeline_step = 2
                    status.write("### Step 2/4: 🧠 AI 마케팅 전략 생성")
                    strategy = generate_marketing_strategy(collected, status)

                    if "error" not in strategy:
                        st.session_state.pipeline_strategy = strategy
                        upload_to_gcs(
                            strategy,
                            GCS_BUCKET_NAME,
                            f"pipeline/strategy_{datetime.date.today()}.json",
                        )
                        status.write("✅ Step 2 완료: 마케팅 전략 생성!")
                    else:
                        status.write(f"⚠️ 전략 생성 오류: {strategy['error']}")

                # Step 3: 썸네일 생성
                if gen_thumbnail and st.session_state.pipeline_strategy:
                    st.session_state.pipeline_step = 3
                    status.write("### Step 3/4: 🖼️ 썸네일 생성")

                    strategy = st.session_state.pipeline_strategy
                    best_hook = strategy.get("hooking_points", [{}])[0]
                    hook_text = best_hook.get("hook", "벌레 싹!")

                    thumb_result = generate_thumbnail(
                        product["name"], hook_text, status
                    )
                    if isinstance(thumb_result, bytes):
                        st.session_state.thumbnail_data = thumb_result
                        status.write("✅ Step 3 완료: 썸네일 생성!")
                    else:
                        status.write(f"⚠️ 썸네일 생성 실패: {thumb_result[:100]}...")

                # Step 4: 영상 생성
                if gen_video and st.session_state.pipeline_strategy:
                    st.session_state.pipeline_step = 4
                    status.write("### Step 4/4: 🎬 숏폼 영상 생성")

                    strategy = st.session_state.pipeline_strategy
                    video_prompt = strategy.get("video_prompt", "")
                    if not video_prompt:
                        video_prompt = generate_marketing_prompt(
                            product, {"hook": "벌레 싹!"}
                        )

                    video_result = generate_video_long_running(video_prompt, status)
                    if isinstance(video_result, bytes):
                        local_file = "pipeline_video.mp4"
                        with open(local_file, "wb") as f:
                            f.write(video_result)
                        st.session_state.video_path = local_file
                        st.session_state.pipeline_content = {"video": video_result}
                        status.write("✅ Step 4 완료: 영상 생성!")
                    else:
                        status.write(f"⚠️ 영상 생성 진행 중: {video_result[:100]}...")

                # 완료
                st.session_state.step1_done = True
                st.session_state.step2_done = True
                st.session_state.step3_done = True
                status.update(
                    label="🎉 파이프라인 완료!", state="complete", expanded=False
                )
                st.rerun()

            except Exception as e:
                status.update(label=f"❌ 오류 발생: {str(e)[:50]}", state="error")

    # 결과 표시 영역
    st.divider()
    st.markdown("##### 📋 파이프라인 결과")

    result_col1, result_col2 = st.columns(2)

    with result_col1:
        # 마케팅 전략 결과
        if st.session_state.pipeline_strategy:
            strategy = st.session_state.pipeline_strategy
            with st.expander("🎯 마케팅 전략", expanded=True):
                # 타겟 페르소나
                if "target_persona" in strategy:
                    persona = strategy["target_persona"]
                    st.markdown(f"**타겟 연령대**: {persona.get('age', 'N/A')}")
                    st.markdown("**고객 페인포인트**:")
                    for pp in persona.get("pain_points", []):
                        st.markdown(f"- {pp}")

                # 후킹 포인트
                if "hooking_points" in strategy:
                    st.markdown("**후킹 포인트**:")
                    for hp in strategy["hooking_points"]:
                        st.markdown(f"- **{hp.get('type', '')}**: {hp.get('hook', '')}")

                # SNS 카피
                if "sns_copies" in strategy:
                    st.markdown("**SNS 마케팅 카피**:")
                    copies = strategy["sns_copies"]
                    if copies.get("instagram"):
                        st.code(copies["instagram"], language=None)
        else:
            st.info("파이프라인을 실행하면 마케팅 전략이 여기에 표시됩니다.")

    with result_col2:
        # 생성된 콘텐츠
        if st.session_state.thumbnail_data:
            with st.expander("🖼️ 생성된 썸네일", expanded=True):
                st.image(st.session_state.thumbnail_data, use_container_width=True)
                st.download_button(
                    "📥 썸네일 다운로드",
                    data=st.session_state.thumbnail_data,
                    file_name=f"{product['name']}_thumbnail.png",
                    mime="image/png",
                    use_container_width=True,
                    key="pipeline_thumbnail_download",
                )

        if st.session_state.video_path:
            with st.expander("🎬 생성된 영상", expanded=True):
                st.video(st.session_state.video_path)
                with open(st.session_state.video_path, "rb") as f:
                    st.download_button(
                        "📥 영상 다운로드",
                        data=f.read(),
                        file_name=f"{product['name']}_shortform.mp4",
                        mime="video/mp4",
                        use_container_width=True,
                        key="pipeline_video_download",
                    )

# --- 탭 1: 데이터 수집 ---
with tab1:
    st.markdown("##### 📰 YouTube 데이터 수집")

    with st.form("collect_form"):
        col1, col2 = st.columns([4, 1])
        with col1:
            keyword = st.text_input(
                "검색 키워드",
                value="AI 기술 트렌드",
                label_visibility="collapsed",
                placeholder="검색 키워드 입력",
            )
        with col2:
            max_results = st.number_input(
                "수", min_value=1, max_value=10, value=3, label_visibility="collapsed"
            )

        submitted = st.form_submit_button("🚀 수집 시작", use_container_width=True)

        if submitted:
            with st.status("수집 중...", expanded=True) as status:
                st.write("🔍 유튜브 검색...")
                videos = search_youtube_videos(keyword, max_results)

                data = []
                for i, v in enumerate(videos):
                    st.write(f"📝 {i + 1}/{len(videos)} 처리중...")
                    t = get_transcript(v["id"])
                    txt = t if t else v["description"]
                    if txt.strip():
                        data.append({"title": v["title"], "text": txt})

                if data:
                    st.write("☁️ 저장 중...")
                    upload_to_gcs(
                        data, GCS_BUCKET_NAME, f"raw_{datetime.date.today()}.json"
                    )
                    st.session_state.collected_data = data
                    st.session_state.step1_done = True
                    status.update(label="✅ 완료!", state="complete", expanded=False)
                    st.rerun()
                else:
                    status.update(label="⚠️ 데이터 없음", state="error")

    # 수집된 데이터 (컴팩트 표시)
    if st.session_state.collected_data:
        st.divider()
        st.markdown("##### 📋 수집된 데이터")
        for i, item in enumerate(
            st.session_state.collected_data[:5]
        ):  # 최대 5개만 표시
            title_short = (
                item["title"][:45] + "..." if len(item["title"]) > 45 else item["title"]
            )
            with st.expander(f"{i + 1}. {title_short}"):
                st.write(
                    item["text"][:300] + "..."
                    if len(item["text"]) > 300
                    else item["text"]
                )

# --- 탭 2: 네이버 쇼핑 ---
with tab2:
    st.markdown("##### 🛒 네이버 쇼핑 데이터 수집")

    with st.form("naver_form"):
        col1, col2 = st.columns([4, 1])
        with col1:
            naver_keyword = st.text_input(
                "검색 키워드",
                value=st.session_state.selected_product["name"],
                label_visibility="collapsed",
                placeholder="상품 검색 키워드",
            )
        with col2:
            naver_max = st.number_input(
                "수", min_value=1, max_value=30, value=10, label_visibility="collapsed"
            )

        naver_submitted = st.form_submit_button("🛒 검색", use_container_width=True)

        if naver_submitted:
            with st.status("검색 중...", expanded=True) as status:
                st.write(f"🔍 '{naver_keyword}' 검색 중...")
                products = search_naver_shopping(naver_keyword, naver_max)

                if products:
                    st.session_state.naver_data = products
                    status.update(
                        label=f"✅ {len(products)}개 상품 발견!",
                        state="complete",
                        expanded=False,
                    )
                    st.rerun()
                else:
                    status.update(label="⚠️ 검색 결과 없음", state="error")

    # 검색된 상품 표시
    if st.session_state.naver_data:
        st.divider()
        st.markdown("##### 📦 검색된 상품")
        for i, item in enumerate(st.session_state.naver_data[:5]):
            with st.expander(f"{i + 1}. {item['title'][:40]}..."):
                col1, col2 = st.columns([1, 3])
                with col1:
                    if item.get("image"):
                        st.image(item["image"], width=80)
                with col2:
                    st.write(f"💰 **{item['price']:,}원**")
                    st.write(f"🏪 {item.get('mall', '알 수 없음')}")

# --- 탭 3: AI 분석 ---
with tab3:
    st.markdown("##### 🧠 Gemini AI 프롬프트 생성")

    if not st.session_state.step1_done:
        st.warning("⚠️ 먼저 데이터 수집을 완료하세요.")
    else:
        if st.button("🧠 AI 분석 시작", use_container_width=True):
            with st.status("분석 중...", expanded=True) as status:
                st.write(f"🤖 {GEMINI_MODEL_NAME} 분석...")
                raw = read_from_gcs(
                    GCS_BUCKET_NAME, f"raw_{datetime.date.today()}.json"
                )

                if raw:
                    prompt = analyze_with_gemini(raw)
                    st.session_state.generated_prompt = prompt
                    st.write("☁️ 저장 중...")
                    upload_to_gcs(
                        prompt, GCS_BUCKET_NAME, "veo_prompt.txt", "text/plain"
                    )
                    st.session_state.step2_done = True
                    status.update(label="✅ 완료!", state="complete", expanded=False)
                    st.rerun()
                else:
                    status.update(label="❌ 로드 실패", state="error")

        if st.session_state.generated_prompt:
            st.divider()
            st.markdown("##### ✏️ 생성된 프롬프트")
            edited = st.text_area(
                "편집",
                value=st.session_state.generated_prompt,
                height=100,
                label_visibility="collapsed",
            )
            if edited != st.session_state.generated_prompt:
                st.session_state.generated_prompt = edited

# --- 탭 4: 썸네일 생성 ---
with tab4:
    st.markdown("##### 🖼️ AI 썸네일 생성")

    product = st.session_state.selected_product
    st.info(f"선택된 제품: **{product['name']}** ({product['target']})")

    hook_text = st.text_input(
        "후킹 문구", value="벌레 싹!", placeholder="썸네일에 표시할 문구"
    )

    if st.button("🖼️ 썸네일 생성", use_container_width=True):
        with st.status("생성 중...", expanded=True) as status:
            result = generate_thumbnail(product["name"], hook_text, status)

            if isinstance(result, bytes):
                st.session_state.thumbnail_data = result
                status.update(label="✅ 생성 완료!", state="complete", expanded=False)
                st.rerun()
            else:
                st.warning(f"이미지 설명: {result[:200]}...")
                status.update(label="⚠️ 텍스트 응답", state="complete")

    if st.session_state.thumbnail_data:
        st.divider()
        st.image(
            st.session_state.thumbnail_data,
            caption="생성된 썸네일",
            use_container_width=True,
        )
        st.download_button(
            "📥 썸네일 다운로드",
            data=st.session_state.thumbnail_data,
            file_name=f"{product['name']}_thumbnail.png",
            mime="image/png",
            use_container_width=True,
        )

# --- 탭 5: 영상 생성 ---
with tab5:
    st.markdown("##### 🎬 Veo AI 영상 생성")

    if not st.session_state.step2_done:
        st.warning("⚠️ 먼저 AI 분석을 완료하세요.")
    else:
        st.code(
            st.session_state.generated_prompt[:150] + "..."
            if len(st.session_state.generated_prompt) > 150
            else st.session_state.generated_prompt,
            language=None,
        )

        if st.button("🎥 영상 생성", use_container_width=True):
            with st.status("렌더링 중...", expanded=True) as status:
                result = generate_video_long_running(
                    st.session_state.generated_prompt, status
                )

                if isinstance(result, str):
                    status.update(label=f"❌ {result[:30]}...", state="error")
                else:
                    local_file = "veo_final.mp4"
                    with open(local_file, "wb") as f:
                        f.write(result)
                    st.session_state.video_path = local_file
                    st.session_state.step3_done = True
                    upload_to_gcs(
                        result,
                        GCS_BUCKET_NAME,
                        f"veo_{datetime.date.today()}.mp4",
                        "video/mp4",
                    )
                    status.update(label="✅ 완료!", state="complete", expanded=False)
                    st.rerun()

        if st.session_state.video_path:
            st.divider()
            st.video(st.session_state.video_path)
            with open(st.session_state.video_path, "rb") as f:
                st.download_button(
                    "📥 다운로드",
                    data=f.read(),
                    file_name="genesis_video.mp4",
                    mime="video/mp4",
                    use_container_width=True,
                )

# 푸터
st.markdown(
    """
<div class="neo-footer">
    <span class="neo-footer-badge">⚡ Gemini & Veo | 제네시스 AI v3.0</span>
</div>
""",
    unsafe_allow_html=True,
)
