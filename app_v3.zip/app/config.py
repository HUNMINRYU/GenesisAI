# ==========================================
# ⚙️ 블루가드 마케팅 대시보드 설정
# ==========================================
import os

# ==========================================
# 🔑 API 키 설정
# ==========================================
YOUTUBE_API_KEY = "AIzaSyAujUhrll43asWHHNHsRMKv8vR4wN1_F28"
GEMINI_API_KEY = "AIzaSyAujUhrll43asWHHNHsRMKv8vR4wN1_F28"

# 🛒 네이버 쇼핑 API
NAVER_CLIENT_ID = "nvExjvRi7TYhl37jYO62"
NAVER_CLIENT_SECRET = "DJ5GZA3qaq"

# ==========================================
# ☁️ GCP 설정
# ==========================================
GOOGLE_CLOUD_PROJECT_ID = "jnu-rise-edu-149"
GCS_BUCKET_NAME = "auto-pipeline-practice"
KEY_FILE = "key.json"
LOCATION = "us-central1"

# ==========================================
# 🤖 AI 모델 설정
# ==========================================
GEMINI_MODEL_NAME = "gemini-2.5-flash"  # 분석용
GEMINI_IMAGE_MODEL = "gemini-3-pro-image-preview"  # 이미지 생성용
VEO_MODEL_ID = "veo-3.1-fast-generate-001"  # 영상 생성용

# ==========================================
# 📦 블루가드 제품 카탈로그 (15개)
# ==========================================
BLUEGUARD_PRODUCTS = [
    {
        "name": "벅스델타",
        "category": "해충방제",
        "description": "델타메트린 기반 희석형 광역살충제",
        "target": "모든 해충",
    },
    {
        "name": "벅스델타S",
        "category": "해충방제",
        "description": "델타메트린 기반 스프레이형 즉석 살충제",
        "target": "모든 해충",
    },
    {
        "name": "벅스라인 산제",
        "category": "해충방제",
        "description": "라인 도포형 가루 살충제",
        "target": "보행해충",
    },
    {
        "name": "블루가드 바퀴벌레겔",
        "category": "바퀴벌레",
        "description": "연쇄 살충효과 먹이겔",
        "target": "바퀴벌레",
    },
    {
        "name": "블루가드 좀벌레트랩",
        "category": "트랩",
        "description": "좀벌레 전문 끈끈이 트랩",
        "target": "좀벌레",
    },
    {
        "name": "블루가드 화랑곡나방트랩",
        "category": "트랩",
        "description": "페로몬 유인 끈끈이 트랩",
        "target": "나방",
    },
    {
        "name": "뱀이싹",
        "category": "기피제",
        "description": "천연유래물질 성분 뱀 기피제",
        "target": "뱀",
    },
    {
        "name": "쥐싹킬",
        "category": "쥐약",
        "description": "나가서 말라죽는 알약형 쥐약",
        "target": "쥐",
    },
    {
        "name": "싹보내 퇴치기",
        "category": "퇴치기",
        "description": "지진파 원리 두더지/뱀 퇴치기",
        "target": "두더지/뱀",
    },
    {
        "name": "싹보내G 퇴치기",
        "category": "퇴치기",
        "description": "3중 퇴치 야생동물용",
        "target": "야생동물",
    },
    {
        "name": "모기싹",
        "category": "해충방제",
        "description": "모기 퇴치 전문 제품",
        "target": "모기",
    },
    {
        "name": "개미싹",
        "category": "해충방제",
        "description": "개미 퇴치 전문 제품",
        "target": "개미",
    },
    {
        "name": "파리싹",
        "category": "해충방제",
        "description": "파리 퇴치 전문 제품",
        "target": "파리",
    },
    {
        "name": "냄새싹",
        "category": "탈취/방향",
        "description": "강력 탈취 제품",
        "target": "악취",
    },
    {
        "name": "블루가드올인원",
        "category": "종합",
        "description": "다기능 통합 솔루션",
        "target": "다용도",
    },
]


def setup_environment():
    """GCP 환경변수 설정"""
    os.environ["GOOGLE_CLOUD_PROJECT"] = GOOGLE_CLOUD_PROJECT_ID
    os.environ["GOOGLE_CLOUD_LOCATION"] = "global"
    os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"

    key_path = os.path.join(os.path.dirname(__file__), KEY_FILE)
    if os.path.exists(key_path):
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = key_path
