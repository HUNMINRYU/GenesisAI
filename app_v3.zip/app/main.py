# ==========================================
# 🦟 BLUEGUARD 마케팅 대시보드
# 메인 엔트리포인트
# ==========================================
import streamlit as st

# 환경 설정
from config import setup_environment, BLUEGUARD_PRODUCTS

setup_environment()

# 스타일 및 컴포넌트
from styles import (
    inject_neobrutalism_css,
    render_header,
    render_footer,
    render_step_item,
)

# 탭 모듈
from tabs import (
    render_pipeline_tab,
    render_youtube_tab,
    render_naver_tab,
    render_analysis_tab,
    render_thumbnail_tab,
    render_video_tab,
    render_report_tab,
    render_abtest_tab,
)


# ==========================================
# 🎨 페이지 설정
# ==========================================
st.set_page_config(
    page_title="GenesisAI Marketing Dashboard",
    page_icon="🦟",
    layout="wide",
    initial_sidebar_state="expanded",
)

# CSS 주입
inject_neobrutalism_css()


# ==========================================
# 📊 세션 상태 초기화
# ==========================================
def init_session_state():
    """세션 상태 초기화"""
    defaults = {
        # 제품 선택
        "selected_product": BLUEGUARD_PRODUCTS[0],
        "product_index": 0,
        # 데이터 수집
        "collected_data": [],
        "naver_data": [],
        "competitor_stats": {},
        # AI 생성
        "generated_prompt": "",
        "thumbnail_data": None,
        "video_path": None,
        "video_data": None,
        # 파이프라인
        "pipeline_collected_data": None,
        "pipeline_strategy": None,
        # 단계 완료 상태
        "step1_done": False,
        "step2_done": False,
        "step3_done": False,
    }

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_session_state()


# ==========================================
# 📱 사이드바
# ==========================================
with st.sidebar:
    st.markdown("### 📦 제품 선택")

    # 제품 선택
    product_names = [p["name"] for p in BLUEGUARD_PRODUCTS]
    selected_index = st.selectbox(
        "블루가드 제품",
        range(len(BLUEGUARD_PRODUCTS)),
        format_func=lambda x: f"{BLUEGUARD_PRODUCTS[x]['name']} ({BLUEGUARD_PRODUCTS[x]['category']})",
        index=st.session_state.product_index,
        label_visibility="collapsed",
    )

    if selected_index != st.session_state.product_index:
        st.session_state.product_index = selected_index
        st.session_state.selected_product = BLUEGUARD_PRODUCTS[selected_index]
        st.rerun()

    product = st.session_state.selected_product

    # 제품 정보 카드 (컴팩트)
    st.markdown(
        f"""
    <div class="neo-card yellow" style="margin-top: 12px; padding: 8px; min-height: auto;">
        <div style="font-size: 1rem; margin-bottom: 2px;">🎯</div>
        <div style="font-size: 1.1rem; font-weight: 700; color: #1A1A1A; margin-bottom: 2px;">{product["name"]}</div>
        <div style="font-size: 0.65rem; color: #525252; text-transform: uppercase; font-weight: 600;">{product["target"]} 퇴치</div>
    </div>
    <div style="background: #DBEAFE; border: 2px solid #1A1A1A; padding: 8px 10px; margin-top: 8px; box-shadow: 2px 2px 0 #1A1A1A;">
        <p style="margin: 0; font-size: 0.85rem; font-weight: 600; color: #1A1A1A !important;">📝 {product["description"]}</p>
    </div>
    """,
        unsafe_allow_html=True,
    )

    st.divider()

    # 진행 상태
    st.markdown("### 📊 진행 상황")

    # 스텝 상태
    step1_status = "complete" if st.session_state.step1_done else ""
    step2_status = "complete" if st.session_state.step2_done else ""
    step3_status = "complete" if st.session_state.step3_done else ""

    st.markdown(
        render_step_item("1️⃣", "데이터 수집", step1_status),
        unsafe_allow_html=True,
    )
    st.markdown(
        render_step_item("2️⃣", "AI 분석", step2_status),
        unsafe_allow_html=True,
    )
    st.markdown(
        render_step_item("3️⃣", "콘텐츠 생성", step3_status),
        unsafe_allow_html=True,
    )

    st.divider()

    # 초기화 버튼
    if st.button("🔄 세션 초기화", use_container_width=True):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()


# ==========================================
# 🏠 메인 헤더
# ==========================================
render_header()


# ==========================================
# 📑 탭 구성
# ==========================================
tab0, tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs(
    [
        "🚀 자동화",
        "📰 YouTube",
        "🛒 네이버",
        "🧠 AI 분석",
        "🖼️ 썸네일",
        "🎬 영상",
        "📊 리포트",
        "🎯 A/B 테스트",
    ]
)

# 각 탭 렌더링
with tab0:
    render_pipeline_tab()

with tab1:
    render_youtube_tab()

with tab2:
    render_naver_tab()

with tab3:
    render_analysis_tab()

with tab4:
    render_thumbnail_tab()

with tab5:
    render_video_tab()

with tab6:
    render_report_tab()

with tab7:
    render_abtest_tab()


# ==========================================
# 🔻 푸터
# ==========================================
render_footer()
