# ==========================================
# 🎨 네오브루탈리즘 CSS 스타일
# ==========================================
import streamlit as st


def inject_neobrutalism_css():
    """네오브루탈리즘 스타일 CSS 주입"""
    st.markdown(
        """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap');
    
    /* === 네오브루탈리즘 색상 팔레트 === */
    :root {
        --bg-cream: #FFFDF7;
        --bg-yellow: #FEF3C7;
        --bg-mint: #D1FAE5;
        --bg-pink: #FCE7F3;
        --bg-blue: #DBEAFE;
        --bg-purple: #EDE9FE;
        --accent-red: #FF6B6B;
        --accent-blue: #4F46E5;
        --accent-green: #10B981;
        --accent-yellow: #FBBF24;
        --accent-purple: #8B5CF6;
        --text-black: #1A1A1A;
        --text-gray: #525252;
        --border-black: #1A1A1A;
    }
    
    /* 기본 폰트 - Material Icons 제외 */
    *:not([data-testid="stIconMaterial"]):not(.material-icons):not([class*="icon"]) {
        font-family: 'Space Grotesk', -apple-system, sans-serif !important;
    }
    
    /* Material Icons 복원 */
    [data-testid="stIconMaterial"],
    .material-icons,
    span[translate="no"][class*="exvv1vr0"] {
        font-family: 'Material Symbols Rounded', 'Material Icons' !important;
    }
    
    /* 앱 배경 */
    .stApp {
        background-color: var(--bg-cream) !important;
    }
    
    /* ===== 컴팩트 레이아웃 ===== */
    .block-container {
        padding-top: 1rem !important;
        padding-bottom: 1rem !important;
        max-width: 1200px !important;
    }
    
    /* 헤더 컴팩트화 */
    .neo-header {
        text-align: center;
        padding: 16px 20px;
        margin-bottom: 16px;
    }
    
    .neo-title {
        font-size: 2rem;
        font-weight: 700;
        color: var(--text-black) !important;
        margin-bottom: 4px;
        letter-spacing: -0.02em;
    }
    
    .neo-title-accent {
        display: inline-block;
        background: var(--accent-yellow);
        padding: 2px 12px;
        border: 2px solid var(--border-black);
        box-shadow: 3px 3px 0 var(--border-black);
        transform: rotate(-1deg);
    }
    
    .neo-subtitle {
        font-size: 0.95rem;
        color: var(--text-gray) !important;
        font-weight: 500;
        margin-top: 8px;
    }
    
    /* 텍스트 색상 */
    h1, h2, h3, h4, h5, h6 {
        color: var(--text-black) !important;
        font-weight: 700 !important;
        margin-top: 0.5rem !important;
        margin-bottom: 0.5rem !important;
    }
    
    h3 { font-size: 1.1rem !important; }
    
    p, span, label, div {
        color: var(--text-gray) !important;
    }
    
    /* 사이드바 */
    section[data-testid="stSidebar"] {
        background: var(--bg-yellow) !important;
        border-right: 3px solid var(--border-black) !important;
        width: 280px !important;
    }
    
    section[data-testid="stSidebar"] > div {
        padding-top: 1rem !important;
    }
    
    /* 네오브루탈리즘 카드 - 컴팩트 */
    .neo-card {
        background: white;
        border: 2px solid var(--border-black);
        border-radius: 0;
        padding: 12px;
        box-shadow: 4px 4px 0 var(--border-black);
        transition: all 0.2s ease;
        text-align: center;
        min-height: 90px;
    }
    
    .neo-card:hover {
        transform: translate(-2px, -2px);
        box-shadow: 6px 6px 0 var(--border-black);
    }
    
    .neo-card.pink { background: var(--bg-pink); }
    .neo-card.blue { background: var(--bg-blue); }
    .neo-card.mint { background: var(--bg-mint); }
    .neo-card.purple { background: var(--bg-purple); }
    .neo-card.yellow { background: var(--bg-yellow); }
    
    .neo-metric-icon {
        font-size: 1.4rem;
        margin-bottom: 4px;
    }
    
    .neo-metric-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--text-black) !important;
        margin-bottom: 2px;
    }
    
    .neo-metric-label {
        font-size: 0.7rem;
        color: var(--text-gray) !important;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    /* 프로그레스 바 */
    .neo-progress {
        background: white;
        border: 2px solid var(--border-black);
        padding: 12px;
        box-shadow: 3px 3px 0 var(--border-black);
        margin: 8px 0;
    }
    
    .neo-progress-track {
        background: var(--bg-cream);
        border: 2px solid var(--border-black);
        height: 16px;
        overflow: hidden;
    }
    
    .neo-progress-fill {
        height: 100%;
        background: var(--accent-green);
        transition: width 0.5s ease;
    }
    
    .neo-progress-text {
        text-align: center;
        margin-top: 8px;
        font-size: 0.9rem;
        font-weight: 700;
        color: var(--text-black) !important;
    }
    
    /* 스텝 아이템 - 컴팩트 */
    .neo-step {
        display: flex;
        align-items: center;
        padding: 8px 12px;
        margin: 4px 0;
        background: white;
        border: 2px solid var(--border-black);
        box-shadow: 2px 2px 0 var(--border-black);
        transition: all 0.2s ease;
    }
    
    .neo-step.complete {
        background: var(--bg-mint);
    }
    
    .neo-step.active {
        background: var(--bg-blue);
    }
    
    .neo-step-icon {
        font-size: 1rem;
        margin-right: 10px;
        font-weight: 700;
    }
    
    .neo-step-label {
        font-weight: 600;
        color: var(--text-black) !important;
        font-size: 0.85rem;
    }
    
    /* 버튼 */
    .stButton > button {
        background: var(--accent-red) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        color: white !important;
        font-weight: 700 !important;
        padding: 10px 20px !important;
        font-size: 0.9rem !important;
        box-shadow: 3px 3px 0 var(--border-black) !important;
        transition: all 0.2s ease !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
    }
    
    .stButton > button:hover {
        transform: translate(-2px, -2px) !important;
        box-shadow: 5px 5px 0 var(--border-black) !important;
    }
    
    .stButton > button:active {
        transform: translate(2px, 2px) !important;
        box-shadow: 1px 1px 0 var(--border-black) !important;
    }
    
    /* 입력 필드 */
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea,
    .stNumberInput > div > div > input {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        color: var(--text-black) !important;
        padding: 8px 12px !important;
        font-weight: 500 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    /* Selectbox 스타일 수정 */
    .stSelectbox > div > div {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
        min-height: 42px !important;
    }
    
    /* Selectbox 선택된 값 텍스트 */
    .stSelectbox [data-baseweb="select"] > div {
        background: white !important;
        min-height: 42px !important;
    }
    
    .stSelectbox [data-baseweb="select"] > div > div {
        color: var(--text-black) !important;
        font-weight: 500 !important;
        overflow: visible !important;
    }
    
    /* Selectbox 내부 value div */
    .stSelectbox [data-baseweb="select"] [value] {
        color: var(--text-black) !important;
        font-size: 0.9rem !important;
        font-weight: 500 !important;
        white-space: nowrap !important;
        overflow: visible !important;
    }
    
    .stTextInput > div > div > input:focus,
    .stTextArea > div > div > textarea:focus {
        border-color: var(--accent-blue) !important;
        box-shadow: 2px 2px 0 var(--accent-blue) !important;
    }
    
    /* 폼 */
    [data-testid="stForm"] {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        padding: 16px !important;
        box-shadow: 4px 4px 0 var(--border-black) !important;
    }
    
    /* ===== 탭 스타일 (재설계) ===== */
    /* 1. 탭 컨테이너 초기화 */
    .stTabs {
        position: relative;
    }

    /* 2. 탭 리스트 - 네오브루탈리즘 스타일 */
    .stTabs [data-baseweb="tab-list"] {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        box-shadow: 3px 3px 0 var(--border-black) !important;
        padding: 0 !important;
        gap: 0 !important;
        display: flex !important;
        flex-direction: row !important;
        align-items: stretch !important;
        justify-content: flex-start !important;
        border-radius: 0 !important;
    }

    /* 3. 개별 탭 버튼 */
    .stTabs [data-baseweb="tab"] {
        background: white !important;
        border-right: 2px solid var(--border-black) !important;
        border-left: none !important;
        border-top: none !important;
        border-bottom: none !important;
        color: var(--text-black) !important;
        font-weight: 600 !important;
        padding: 10px 16px !important;
        border-radius: 0 !important;
        font-size: 0.85rem !important;
        height: auto !important;
        min-height: 44px !important;
    }

    /* 4. 마지막 탭 오른쪽 테두리 제거 */
    .stTabs [data-baseweb="tab"]:last-child {
        border-right: none !important;
    }

    /* 5. 선택된 탭 강조 */
    .stTabs [data-baseweb="tab"][aria-selected="true"] {
        background: var(--accent-yellow) !important;
        color: var(--text-black) !important;
        font-weight: 700 !important;
    }

    /* 6. 탭 호버 효과 */
    .stTabs [data-baseweb="tab"]:hover {
        background: var(--bg-cream) !important;
    }

    .stTabs [data-baseweb="tab"][aria-selected="true"]:hover {
        background: var(--accent-yellow) !important;
    }

    /* 7. 탭 패널 (내용 영역) */
    .stTabs [data-baseweb="tab-panel"] {
        padding-top: 1rem !important;
    }

    /* 8. Streamlit 동적 클래스 처리 */
    .stTabs button[data-baseweb="tab"] > div {
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    
    /* ===== Expander 수정 (텍스트 겹침 해결) ===== */
    .streamlit-expanderHeader {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
        padding: 10px 16px !important;
        font-size: 0.85rem !important;
    }

    .streamlit-expanderHeader p {
        margin: 0 !important;
        padding-left: 8px !important;
        font-weight: 600 !important;
        color: var(--text-black) !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
    }

    /* Expander 아이콘과 텍스트 간격 */
    .streamlit-expanderHeader svg {
        margin-right: 8px !important;
        flex-shrink: 0 !important;
    }

    .streamlit-expanderContent {
        background: var(--bg-cream) !important;
        border: 2px solid var(--border-black) !important;
        border-top: none !important;
        border-radius: 0 !important;
        padding: 12px !important;
        font-size: 0.85rem !important;
    }
    
    /* 알림 메시지 */
    .stSuccess, .stInfo, .stWarning, .stError {
        padding: 10px 14px !important;
        font-size: 0.85rem !important;
    }
    
    .stSuccess {
        background: var(--bg-mint) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    .stInfo {
        background: var(--bg-blue) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    .stWarning {
        background: var(--bg-yellow) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    .stError {
        background: var(--bg-pink) !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
    }
    
    /* 비디오 */
    video {
        border: 2px solid var(--border-black) !important;
        box-shadow: 4px 4px 0 var(--border-black) !important;
    }
    
    /* 코드 블록 */
    .stCodeBlock {
        background: white !important;
        border: 2px solid var(--border-black) !important;
        border-radius: 0 !important;
        box-shadow: 2px 2px 0 var(--border-black) !important;
        font-size: 0.8rem !important;
    }
    
    /* 구분선 */
    hr {
        border: 1px solid var(--border-black) !important;
        margin: 12px 0 !important;
    }
    
    /* 푸터 */
    .neo-footer {
        text-align: center;
        padding: 16px;
        margin-top: 12px;
    }
    
    .neo-footer-badge {
        display: inline-block;
        background: var(--accent-purple);
        color: white !important;
        padding: 6px 16px;
        border: 2px solid var(--border-black);
        box-shadow: 3px 3px 0 var(--border-black);
        font-weight: 700;
        font-size: 0.8rem;
    }
    
    /* Status 컴포넌트 컴팩트화 */
    [data-testid="stStatusWidget"] {
        font-size: 0.85rem !important;
    }
    
    /* Caption 스타일 */
    .stCaption {
        font-size: 0.8rem !important;
        margin-bottom: 8px !important;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )


def render_header():
    """네오브루탈리즘 헤더 렌더링"""
    st.markdown(
        """
    <div class="neo-header">
        <h1 class="neo-title">🛡️ <span class="neo-title-accent">GENESIS AI</span> 마케팅 대시보드</h1>
        <p class="neo-subtitle">AI 기반 숏폼 콘텐츠 자동화 파이프라인</p>
    </div>
    """,
        unsafe_allow_html=True,
    )


def render_footer():
    """네오브루탈리즘 푸터 렌더링"""
    st.markdown(
        """
    <div class="neo-footer">
        <span class="neo-footer-badge">🚀 Vertex AI + Gemini + Veo 3.1 Powered</span>
    </div>
    """,
        unsafe_allow_html=True,
    )


def render_metric_card(icon: str, value: str, label: str, color: str = ""):
    """네오브루탈리즘 메트릭 카드 렌더링"""
    return f"""
    <div class="neo-card {color}">
        <div class="neo-metric-icon">{icon}</div>
        <div class="neo-metric-value">{value}</div>
        <div class="neo-metric-label">{label}</div>
    </div>
    """


def render_step_item(icon: str, label: str, status: str = ""):
    """네오브루탈리즘 스텝 아이템 렌더링"""
    return f"""
    <div class="neo-step {status}">
        <span class="neo-step-icon">{icon}</span>
        <span class="neo-step-label">{label}</span>
    </div>
    """


def render_progress_bar(progress: int, label: str = ""):
    """네오브루탈리즘 프로그레스 바 렌더링"""
    return f"""
    <div class="neo-progress">
        <div class="neo-progress-track">
            <div class="neo-progress-fill" style="width: {progress}%"></div>
        </div>
        <div class="neo-progress-text">{label if label else f"{progress}%"}</div>
    </div>
    """
