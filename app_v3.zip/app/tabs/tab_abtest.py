# ==========================================
# 🎯 A/B 테스트 탭
# ==========================================
import streamlit as st

from config import BLUEGUARD_PRODUCTS
from api.gemini import build_multi_style_prompts


def render_abtest_tab():
    """A/B 테스트 탭 렌더링"""
    st.markdown("##### 🎯 A/B 테스트 시뮬레이션")
    st.caption("후킹 문구 비교 및 CTR 예측")

    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    st.info(f"📦 **제품**: {product['name']} - {product['description']}")

    # 테스트 방식 선택
    test_mode = st.radio(
        "테스트 방식",
        ["📝 후킹 문구 비교", "🖼️ 썸네일 비교", "🎨 3종 스타일 비교"],
        horizontal=True,
        key="abtest_mode",
    )

    st.divider()

    if test_mode == "📝 후킹 문구 비교":
        render_hook_comparison(product)
    elif test_mode == "🖼️ 썸네일 비교":
        render_thumbnail_comparison(product)
    else:
        render_style_comparison(product)


def render_hook_comparison(product):
    """후킹 문구 A/B 비교"""
    st.markdown("#### 📝 후킹 문구 A/B 테스트")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**버전 A**")
        hook_a = st.text_area(
            "후킹 문구 A",
            value=f"{product['target']} 1마리 보이면? 30마리가 숨어있다!",
            height=100,
            key="hook_a",
            label_visibility="collapsed",
        )

    with col2:
        st.markdown("**버전 B**")
        hook_b = st.text_area(
            "후킹 문구 B",
            value=f"전문가들이 살충제 대신 {product['name']}을 쓰는 이유",
            height=100,
            key="hook_b",
            label_visibility="collapsed",
        )

    # 타겟 설정
    st.markdown("**🎯 타겟 오디언스**")
    col1, col2, col3 = st.columns(3)
    with col1:
        age_range = st.selectbox(
            "연령대",
            ["20-30대", "30-40대", "40-50대", "50-60대", "전연령"],
            index=2,
            key="target_age",
        )
    with col2:
        gender = st.selectbox(
            "성별", ["여성", "남성", "전체"], index=0, key="target_gender"
        )
    with col3:
        platform = st.selectbox(
            "플랫폼",
            ["YouTube Shorts", "Instagram Reels", "TikTok"],
            key="target_platform",
        )

    if st.button("🔮 CTR 예측 분석", use_container_width=True, type="primary"):
        predict_ctr(hook_a, hook_b, age_range, gender, platform, product)


def predict_ctr(hook_a, hook_b, age_range, gender, platform, product):
    """Gemini를 이용한 CTR 예측"""
    from api.gemini import generate_with_gemini

    with st.spinner("AI 분석 중..."):
        prompt = f"""
다음 두 마케팅 후킹 문구의 CTR(클릭률)을 예측하고 비교 분석해주세요.

제품: {product["name"]} - {product["description"]}
타겟: {age_range} {gender}, {platform} 사용자

**버전 A**: {hook_a}
**버전 B**: {hook_b}

다음 형식으로 답변해주세요:

## 예상 CTR
- 버전 A: X.X% (예상 범위: X.X% ~ X.X%)
- 버전 B: X.X% (예상 범위: X.X% ~ X.X%)

## 승자 예측
(A 또는 B) - 예상 승률: XX%

## 분석 근거
1. (구체적 이유 1)
2. (구체적 이유 2)
3. (구체적 이유 3)

## 개선 제안
- (버전 A 개선점)
- (버전 B 개선점)
"""

        result = generate_with_gemini(prompt)

        if result and "error" not in str(result).lower():
            st.success("분석 완료!")

            # 결과 표시
            st.markdown("---")
            st.markdown(result)

            # 세션에 저장
            st.session_state.abtest_result = {
                "hook_a": hook_a,
                "hook_b": hook_b,
                "target": f"{age_range} {gender}",
                "platform": platform,
                "result": result,
            }
        else:
            st.error("분석 실패. 다시 시도해주세요.")


def render_thumbnail_comparison(product):
    """썸네일 A/B 비교"""
    st.markdown("#### 🖼️ 썸네일 A/B 테스트")

    st.info("파이프라인에서 생성된 썸네일을 비교합니다.")

    # 세션에서 생성된 썸네일 가져오기
    multi_thumbs = st.session_state.get("multi_thumbnails", [])
    single_thumb = st.session_state.get("thumbnail_data")

    if multi_thumbs:
        st.markdown("**생성된 3종 썸네일 비교**")
        cols = st.columns(3)
        for i, thumb in enumerate(multi_thumbs):
            with cols[i]:
                if thumb.get("image"):
                    st.image(thumb["image"], caption=thumb["type"], width=200)
                    if st.button(f"✅ {thumb['type']} 선택", key=f"select_thumb_{i}"):
                        st.session_state.selected_thumbnail = thumb
                        st.success(f"{thumb['type']} 썸네일이 선택되었습니다!")
    elif single_thumb:
        st.image(single_thumb, caption="생성된 썸네일", width=300)
    else:
        st.warning("생성된 썸네일이 없습니다. 먼저 파이프라인을 실행해주세요.")


def render_style_comparison(product):
    """3종 스타일 비교"""
    st.markdown("#### 🎨 3종 스타일 비교")

    # 세션에서 전략 가져오기
    strategy = st.session_state.get("pipeline_strategy", {})

    if not strategy or "error" in strategy:
        st.warning("마케팅 전략이 없습니다. 먼저 파이프라인을 실행해주세요.")

        # 샘플 생성
        if st.button("📋 샘플 스타일 생성", use_container_width=True):
            generate_sample_styles(product)
        return

    # 기존 전략에서 후킹 포인트 표시
    hooks = strategy.get("hooking_points", [])

    if hooks:
        st.markdown("**현재 후킹 포인트**")
        for i, hook in enumerate(hooks[:3]):
            with st.expander(
                f"스타일 {i + 1}: {hook.get('type', '미분류')}", expanded=i == 0
            ):
                st.markdown(f"**후킹 문구**: {hook.get('hook', '')}")
                st.markdown(f"**이유**: {hook.get('reason', '')}")

    # 새로운 3종 스타일 생성
    st.divider()

    if st.button("🔄 새로운 3종 스타일 생성", use_container_width=True):
        prompts = build_multi_style_prompts(product, "해충 퇴치")
        st.session_state.multi_style_prompts = prompts

        for p in prompts:
            with st.expander(f"🎨 {p['type']}", expanded=True):
                st.markdown(f"**스타일**: {p['style']}")
                st.markdown(f"**색상**: {p['color_scheme']}")
                st.code(p["image_prompt"][:300] + "...", language=None)


def generate_sample_styles(product):
    """샘플 스타일 생성"""
    sample_hooks = [
        {
            "type": "공포형",
            "hook": f"{product['target']} 1마리 = 30마리가 숨어있다!",
            "reason": "불안감을 자극하여 즉각적인 행동 유도",
        },
        {
            "type": "정보형",
            "hook": f"전문가가 알려주는 {product['target']} 완벽 퇴치법",
            "reason": "신뢰성 있는 정보 제공으로 관심 유도",
        },
        {
            "type": "유머형",
            "hook": f"{product['target']}들의 최악의 적수가 등장했다",
            "reason": "재미있는 표현으로 공유 유도",
        },
    ]

    st.success("샘플 스타일 생성 완료!")

    for hook in sample_hooks:
        with st.expander(f"🎨 {hook['type']}", expanded=True):
            st.markdown(f"**후킹**: {hook['hook']}")
            st.markdown(f"**이유**: {hook['reason']}")
