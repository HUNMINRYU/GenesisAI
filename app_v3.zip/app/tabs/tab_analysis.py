# ==========================================
# 🧠 AI 분석 탭
# ==========================================
import streamlit as st
import datetime

from config import BLUEGUARD_PRODUCTS, GCS_BUCKET_NAME, GEMINI_MODEL_NAME
from api.gemini import analyze_with_gemini
from api.gcs import read_from_gcs, upload_to_gcs


def render_analysis_tab():
    """AI 분석 탭 렌더링"""
    st.markdown("##### 🧠 Gemini AI 프롬프트 생성")
    st.caption("수집된 데이터 기반 마케팅 영상 프롬프트 생성")

    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    if not st.session_state.get("step1_done"):
        st.warning("⚠️ 먼저 데이터 수집을 완료하세요.")
    else:
        st.info(f"📦 **분석 대상 제품**: {product['name']} ({product['target']} 퇴치)")

        if st.button("🧠 AI 분석 시작", use_container_width=True):
            with st.status("분석 중...", expanded=True) as status:
                st.write(f"🤖 {GEMINI_MODEL_NAME} 분석...")

                # 제품별 수집 데이터 로드
                filename = f"youtube/{product['name']}/raw_{datetime.date.today()}.json"
                raw = read_from_gcs(GCS_BUCKET_NAME, filename)

                # 대체: 일반 raw 데이터 로드
                if not raw:
                    raw = read_from_gcs(
                        GCS_BUCKET_NAME, f"raw_{datetime.date.today()}.json"
                    )

                if raw:
                    # 제품 정보와 함께 분석
                    prompt = analyze_with_gemini(
                        raw, product=product, logger=status.write
                    )
                    st.session_state.generated_prompt = prompt

                    st.write("☁️ 저장 중...")
                    upload_to_gcs(
                        prompt,
                        GCS_BUCKET_NAME,
                        f"prompts/{product['name']}/veo_prompt_{datetime.date.today()}.txt",
                        "text/plain",
                    )
                    st.session_state.step2_done = True
                    status.update(label="✅ 완료!", state="complete", expanded=False)
                    st.rerun()
                else:
                    status.update(label="❌ 수집 데이터 로드 실패", state="error")
                    st.error(
                        "수집된 데이터를 찾을 수 없습니다. YouTube 탭에서 먼저 데이터를 수집하세요."
                    )

        if st.session_state.get("generated_prompt"):
            st.divider()
            st.markdown("##### ✏️ 생성된 프롬프트")

            # 프롬프트 편집
            edited = st.text_area(
                "편집",
                value=st.session_state.generated_prompt,
                height=150,
                label_visibility="collapsed",
            )

            if edited != st.session_state.generated_prompt:
                st.session_state.generated_prompt = edited

            # 복사 버튼
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📋 클립보드 복사", use_container_width=True):
                    st.code(st.session_state.generated_prompt)
                    st.success("위 내용을 복사하세요!")
            with col2:
                if st.button("💾 프롬프트 저장", use_container_width=True):
                    upload_to_gcs(
                        edited,
                        GCS_BUCKET_NAME,
                        f"prompts/{product['name']}/edited_prompt_{datetime.date.today()}.txt",
                        "text/plain",
                    )
                    st.success("✅ 저장 완료!")
