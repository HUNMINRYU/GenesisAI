# ==========================================
# 🛒 네이버 쇼핑 탭
# ==========================================
import streamlit as st
import datetime

from config import BLUEGUARD_PRODUCTS, GCS_BUCKET_NAME
from api.naver import search_naver_shopping, analyze_competitors
from api.gcs import upload_to_gcs
from styles import render_metric_card


def render_naver_tab():
    """네이버 쇼핑 탭 렌더링"""
    st.markdown("##### 🛒 네이버 쇼핑 경쟁사 분석")
    st.caption("경쟁 상품 가격 및 트렌드 분석")

    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    # 검색 폼
    with st.form("naver_search_form"):
        col1, col2 = st.columns([3, 1])
        with col1:
            keyword = st.text_input(
                "검색 키워드",
                value=product["name"],
                label_visibility="collapsed",
                placeholder="상품명 입력...",
            )
        with col2:
            max_results = st.number_input(
                "수", min_value=5, max_value=30, value=10, label_visibility="collapsed"
            )

        submitted = st.form_submit_button("🔍 경쟁사 분석", use_container_width=True)

        if submitted:
            with st.status("검색 중...", expanded=True) as status:
                st.write(f"🛒 '{keyword}' 네이버 쇼핑 검색...")
                products = search_naver_shopping(keyword, max_results)

                if products:
                    st.session_state.naver_data = products

                    # 경쟁사 분석
                    stats = analyze_competitors(products)
                    st.session_state.competitor_stats = stats

                    # GCS 저장
                    filename = (
                        f"naver/{product['name']}/data_{datetime.date.today()}.json"
                    )
                    upload_to_gcs(
                        {
                            "keyword": keyword,
                            "products": products,
                            "stats": stats,
                        },
                        GCS_BUCKET_NAME,
                        filename,
                    )

                    status.update(
                        label=f"✅ {len(products)}개 상품 분석 완료!", state="complete"
                    )
                    st.rerun()
                else:
                    status.update(label="⚠️ 검색 결과 없음", state="error")

    # 분석 결과
    if st.session_state.get("naver_data"):
        st.divider()

        # 경쟁사 가격 통계
        stats = st.session_state.get("competitor_stats", {})

        st.markdown("##### 📊 경쟁사 가격 분석")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.markdown(
                render_metric_card("📦", str(stats.get("count", 0)), "상품 수", "blue"),
                unsafe_allow_html=True,
            )
        with col2:
            st.markdown(
                render_metric_card(
                    "💰", f"{stats.get('min', 0):,}원", "최저가", "mint"
                ),
                unsafe_allow_html=True,
            )
        with col3:
            st.markdown(
                render_metric_card(
                    "💎", f"{stats.get('max', 0):,}원", "최고가", "pink"
                ),
                unsafe_allow_html=True,
            )
        with col4:
            st.markdown(
                render_metric_card(
                    "📈", f"{stats.get('avg', 0):,}원", "평균가", "yellow"
                ),
                unsafe_allow_html=True,
            )

        st.divider()
        st.markdown("##### 🛍️ 경쟁 상품 목록")

        for i, item in enumerate(st.session_state.naver_data[:5]):
            with st.expander(f"{i + 1}. {item['title'][:40]}..."):
                col1, col2 = st.columns([1, 3])
                with col1:
                    if item.get("image"):
                        st.image(item["image"], width=80)
                with col2:
                    st.write(f"💰 **{item['price']:,}원**")
                    st.write(f"🏪 {item.get('mall', '알 수 없음')}")
                    if item.get("brand"):
                        st.write(f"🏷️ {item['brand']}")
