# ==========================================
# 🚀 자동화 파이프라인 탭
# ==========================================
import streamlit as st
from datetime import datetime as dt

from config import BLUEGUARD_PRODUCTS, GCS_BUCKET_NAME
from api.youtube import collect_youtube_data
from api.naver import search_naver_shopping, analyze_competitors
from api.gemini import (
    generate_marketing_strategy,
    generate_thumbnail,
    generate_multi_thumbnails,
)
from api.veo import generate_video_long_running
from api.gcs import upload_to_gcs


def render_pipeline_tab():
    """자동화 파이프라인 탭 렌더링"""
    st.markdown("##### 🚀 원클릭 마케팅 콘텐츠 자동화")
    st.caption("제품 선택 → 데이터 수집 → AI 전략 → 콘텐츠 생성을 한 번에!")

    # 제품 선택
    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    st.info(f"📦 **선택된 제품**: {product['name']} - {product['description']}")

    # 설정 영역
    st.markdown("**📊 데이터 수집 설정**")
    col1, col2, col3 = st.columns(3)
    with col1:
        youtube_count = st.slider(
            "YouTube 영상 수",
            min_value=1,
            max_value=10,
            value=3,
            key="pipeline_youtube_count",
        )
    with col2:
        naver_count = st.slider(
            "네이버 상품 수",
            min_value=5,
            max_value=30,
            value=10,
            key="pipeline_naver_count",
        )
    with col3:
        include_comments = st.checkbox(
            "💬 댓글 분석",
            value=True,
            key="pipeline_include_comments",
            help="YouTube 댓글에서 페인포인트/게인포인트 추출",
        )

    # 생성 옵션
    st.markdown("**🎨 콘텐츠 생성 옵션**")
    col1, col2, col3 = st.columns(3)
    with col1:
        gen_thumbnail = st.checkbox(
            "🖼️ 썸네일 이미지", value=True, key="pipeline_gen_thumb"
        )
    with col2:
        multi_thumbnail = st.checkbox(
            "🎨 3종 동시 생성",
            value=False,
            key="pipeline_multi_thumb",
            disabled=not gen_thumbnail,
        )
    with col3:
        gen_video = st.checkbox("🎬 숏폼 영상", value=True, key="pipeline_gen_video")

    st.divider()

    # 파이프라인 실행 버튼
    if st.button("🚀 전체 파이프라인 실행", use_container_width=True, type="primary"):
        run_full_pipeline(
            product,
            youtube_count,
            naver_count,
            gen_thumbnail,
            gen_video,
            multi_thumbnail,
            include_comments,
        )

    # 결과 표시
    render_pipeline_results(product)


def run_full_pipeline(
    product,
    youtube_count,
    naver_count,
    gen_thumbnail,
    gen_video,
    multi_thumbnail=False,
    include_comments=True,
):
    """전체 파이프라인 실행"""
    with st.status("🔄 파이프라인 실행 중...", expanded=True) as status:
        # 1단계: 데이터 수집
        status.write("📡 **1단계: 데이터 수집**")

        # YouTube 데이터 수집 (확장)
        status.write(f"🎬 YouTube 검색: {product['name']} + {product['target']} 퇴치")
        youtube_result = collect_youtube_data(
            product, youtube_count, include_comments=include_comments
        )

        # 확장된 반환값 처리
        youtube_data = (
            youtube_result.get("videos", [])
            if isinstance(youtube_result, dict)
            else youtube_result
        )
        pain_points = (
            youtube_result.get("pain_points", [])
            if isinstance(youtube_result, dict)
            else []
        )
        gain_points = (
            youtube_result.get("gain_points", [])
            if isinstance(youtube_result, dict)
            else []
        )
        comments_total = (
            youtube_result.get("comments_total", 0)
            if isinstance(youtube_result, dict)
            else 0
        )

        # 네이버 데이터 수집
        status.write(f"🛒 네이버 쇼핑 검색: {product['name']}")
        naver_data = search_naver_shopping(product["name"], naver_count)
        competitor_stats = analyze_competitors(naver_data)

        collected_data = {
            "product": product,
            "youtube_data": youtube_data,
            "naver_data": naver_data,
            "competitor_stats": competitor_stats,
            "pain_points": pain_points,
            "gain_points": gain_points,
            "comments_total": comments_total,
            "collected_at": dt.now().isoformat(),
        }

        # GCS에 수집 데이터 저장
        date_str = dt.now().strftime("%Y%m%d")
        upload_to_gcs(
            collected_data,
            GCS_BUCKET_NAME,
            f"pipeline/{product['name']}/collected_data_{date_str}.json",
        )
        st.session_state.pipeline_collected_data = collected_data

        comments_msg = f", 댓글 {comments_total}건 분석" if include_comments else ""
        status.write(
            f"✅ 수집 완료: YouTube {len(youtube_data)}건, 네이버 {len(naver_data)}건{comments_msg}"
        )

        if pain_points:
            status.write(f"  📍 페인포인트: {len(pain_points)}개 발견")
        if gain_points:
            status.write(f"  ✨ 게인포인트: {len(gain_points)}개 발견")

        # 2단계: AI 마케팅 전략 생성
        status.write("🧠 **2단계: AI 마케팅 전략 생성**")
        strategy = generate_marketing_strategy(collected_data, logger=status.write)

        if "error" not in strategy:
            st.session_state.pipeline_strategy = strategy
            upload_to_gcs(
                strategy,
                GCS_BUCKET_NAME,
                f"pipeline/{product['name']}/strategy_{date_str}.json",
            )
            status.write("✅ 마케팅 전략 생성 완료!")
        else:
            status.write(f"⚠️ 전략 생성 실패: {strategy.get('error', 'Unknown error')}")
            status.update(label="❌ 파이프라인 실패", state="error")
            return

        # 3단계: 콘텐츠 생성
        status.write("🎨 **3단계: 콘텐츠 생성**")

        # 썸네일 생성
        if gen_thumbnail:
            hook_text = ""
            if strategy.get("hooking_points"):
                hook_text = strategy["hooking_points"][0].get("hook", product["name"])
            else:
                hook_text = f"{product['name']} 효과 대박!"

            if multi_thumbnail:
                # 3종 동시 생성
                status.write("🎨 3종 썸네일 생성 중...")
                thumbnails = generate_multi_thumbnails(
                    product, hook_text, logger=status.write
                )
                st.session_state.multi_thumbnails = thumbnails

                for t in thumbnails:
                    if t["image"]:
                        filename = f"pipeline/{product['name']}/thumbnails/{t['type']}_{date_str}.png"
                        upload_to_gcs(
                            t["image"], GCS_BUCKET_NAME, filename, "image/png"
                        )

                status.write("✅ 3종 썸네일 생성 완료!")
            else:
                # 단일 썸네일 생성
                status.write(f"🖼️ 썸네일 생성 중... (후킹: {hook_text[:20]}...)")
                thumbnail_result = generate_thumbnail(
                    product["name"], hook_text, logger=status.write
                )

                if isinstance(thumbnail_result, bytes):
                    st.session_state.thumbnail_data = thumbnail_result
                    thumbnail_filename = (
                        f"pipeline/{product['name']}/thumbnails/thumb_{date_str}.png"
                    )
                    upload_to_gcs(
                        thumbnail_result,
                        GCS_BUCKET_NAME,
                        thumbnail_filename,
                        "image/png",
                    )
                    status.write("✅ 썸네일 생성 및 업로드 완료!")
                else:
                    status.write(f"⚠️ 썸네일 생성 실패: {thumbnail_result}")

        # 영상 생성
        if gen_video:
            video_prompt = strategy.get("video_prompt", "")
            if not video_prompt:
                video_prompt = f"Cinematic pest control product {product['name']} advertisement, 4k quality, professional marketing"

            status.write("🎬 숏폼 영상 생성 중... (약 2분 소요)")
            video_result = generate_video_long_running(
                video_prompt, logger=status.write
            )

            if isinstance(video_result, bytes):
                # 로컬 저장
                video_path = f"pipeline_{product['name']}_{date_str}.mp4"
                with open(video_path, "wb") as f:
                    f.write(video_result)
                st.session_state.video_path = video_path
                status.write("✅ 숏폼 영상 생성 완료!")
            else:
                status.write(f"ℹ️ 영상 상태: {video_result}")

        status.update(label="✅ 파이프라인 완료!", state="complete", expanded=False)
        st.balloons()


def render_pipeline_results(product):
    """파이프라인 결과 표시"""

    # 댓글 분석 결과 (새로 추가)
    collected = st.session_state.get("pipeline_collected_data") or {}
    pain_points = collected.get("pain_points", []) if collected else []
    gain_points = collected.get("gain_points", []) if collected else []

    if pain_points or gain_points:
        with st.expander("💬 댓글 분석 결과", expanded=False):
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**📍 페인포인트 (불만)**")
                for p in pain_points[:5]:
                    if p and isinstance(p, dict) and p.get("text"):
                        text = p["text"][:80]
                        st.markdown(f"• _{text}_...")
            with col2:
                st.markdown("**✨ 게인포인트 (호평)**")
                for g in gain_points[:5]:
                    if g and isinstance(g, dict) and g.get("text"):
                        text = g["text"][:80]
                        st.markdown(f"• _{text}_...")

    result_col1, result_col2 = st.columns(2)

    with result_col1:
        # 마케팅 전략 표시
        strategy = st.session_state.get("pipeline_strategy")
        if strategy and "error" not in strategy:
            with st.expander("📊 마케팅 전략", expanded=True):
                # 타겟 페르소나
                if "target_persona" in strategy:
                    persona = strategy["target_persona"]
                    st.markdown(f"**타겟**: {persona.get('age', '알 수 없음')}")

                    if persona.get("pain_points"):
                        st.markdown("**고통 포인트**:")
                        for pp in persona["pain_points"][:3]:
                            st.markdown(f"• {pp}")

                # 후킹 포인트
                if strategy.get("hooking_points"):
                    st.markdown("**후킹 포인트**:")
                    for hp in strategy["hooking_points"][:3]:
                        st.markdown(f"- **{hp.get('type', '')}**: {hp.get('hook', '')}")

                # SNS 카피
                if strategy.get("sns_copies"):
                    st.markdown("**SNS 마케팅 카피**:")
                    copies = strategy["sns_copies"]
                    if copies.get("instagram"):
                        st.code(copies["instagram"], language=None)
        else:
            st.info("파이프라인을 실행하면 마케팅 전략이 여기에 표시됩니다.")

    with result_col2:
        # 생성된 콘텐츠

        # 3종 썸네일
        if st.session_state.get("multi_thumbnails"):
            with st.expander("🎨 생성된 3종 썸네일", expanded=True):
                for thumb in st.session_state.multi_thumbnails:
                    if thumb["image"]:
                        st.markdown(f"**{thumb['type']}**")
                        st.image(thumb["image"], width=200)

        # 단일 썸네일
        elif st.session_state.get("thumbnail_data"):
            with st.expander("🖼️ 생성된 썸네일", expanded=True):
                st.image(st.session_state.thumbnail_data, use_container_width=True)
                st.download_button(
                    "📥 썸네일 다운로드",
                    data=st.session_state.thumbnail_data,
                    file_name=f"{product['name']}_thumbnail.png",
                    mime="image/png",
                    use_container_width=True,
                    key="pipeline_thumbnail_download",
                )

        if st.session_state.get("video_path"):
            with st.expander("🎬 생성된 영상", expanded=True):
                st.video(st.session_state.video_path)
                with open(st.session_state.video_path, "rb") as f:
                    st.download_button(
                        "📥 영상 다운로드",
                        data=f.read(),
                        file_name=f"{product['name']}_shortform.mp4",
                        mime="video/mp4",
                        use_container_width=True,
                        key="pipeline_video_download",
                    )
