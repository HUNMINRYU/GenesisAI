# ==========================================
# 📊 리포트/히스토리 탭
# ==========================================
import streamlit as st

from config import BLUEGUARD_PRODUCTS, GCS_BUCKET_NAME
from api.gcs import list_gcs_files


def render_report_tab():
    """리포트/히스토리 탭 렌더링"""
    st.markdown("##### 📊 마케팅 리포트 & 히스토리")
    st.caption("수집/분석/생성 히스토리 및 성과 요약")

    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    st.info(f"📦 **제품**: {product['name']} - {product['description']}")

    # 탭 구분
    report_tab1, report_tab2, report_tab3 = st.tabs(
        ["📈 성과 요약", "📂 GCS 히스토리", "🎯 콘텐츠 갤러리"]
    )

    with report_tab1:
        render_performance_summary(product)

    with report_tab2:
        render_gcs_history(product)

    with report_tab3:
        render_content_gallery(product)


def render_performance_summary(product):
    """성과 요약 표시"""
    st.markdown("#### 📈 세션 성과 요약")

    # 세션에서 수집한 데이터 가져오기
    collected = st.session_state.get("pipeline_collected_data", {})
    strategy = st.session_state.get("pipeline_strategy", {})

    if not collected:
        st.warning("아직 수집된 데이터가 없습니다. 파이프라인을 먼저 실행해주세요.")

        # 샘플 데이터로 미리보기
        with st.expander("📋 샘플 리포트 미리보기", expanded=True):
            show_sample_report()
        return

    # 수집 데이터 메트릭
    st.markdown("##### 📥 데이터 수집 현황")
    col1, col2, col3, col4 = st.columns(4)

    youtube_data = collected.get("youtube_data", [])
    naver_data = collected.get("naver_data", [])
    pain_points = collected.get("pain_points", [])
    gain_points = collected.get("gain_points", [])

    with col1:
        st.metric("YouTube 영상", len(youtube_data))
    with col2:
        st.metric("네이버 상품", len(naver_data))
    with col3:
        st.metric("페인포인트", len(pain_points))
    with col4:
        st.metric("게인포인트", len(gain_points))

    st.divider()

    # 마케팅 전략 요약
    if strategy and "error" not in strategy:
        st.markdown("##### 🧠 AI 마케팅 전략 요약")

        # 후킹 포인트
        if strategy.get("hooking_points"):
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**🎣 후킹 포인트**")
                for hp in strategy["hooking_points"][:3]:
                    hp_type = hp.get("type", "")
                    hp_hook = hp.get("hook", "")
                    st.markdown(f"- **{hp_type}**: {hp_hook}")

            with col2:
                st.markdown("**📝 SNS 카피**")
                copies = strategy.get("sns_copies", {})
                if copies.get("instagram"):
                    st.code(copies["instagram"][:150] + "...", language=None)

        # 프롬프트 정보
        st.markdown("##### 🎨 생성 프롬프트")

        if strategy.get("thumbnail_prompt"):
            with st.expander("🖼️ 썸네일 프롬프트", expanded=False):
                st.code(strategy["thumbnail_prompt"][:500], language=None)

        if strategy.get("video_prompt"):
            with st.expander("🎬 영상 프롬프트", expanded=False):
                st.code(strategy["video_prompt"][:500], language=None)

    # 수집 타임스탬프
    collected_at = collected.get("collected_at", "")
    if collected_at:
        st.caption(f"🕐 마지막 수집: {collected_at}")


def show_sample_report():
    """샘플 리포트 표시"""
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("YouTube 영상", 5, delta="+2")
    with col2:
        st.metric("네이버 상품", 10, delta="+3")
    with col3:
        st.metric("페인포인트", 8)
    with col4:
        st.metric("게인포인트", 6)

    st.markdown("---")
    st.markdown("**🎣 샘플 후킹 포인트**")
    st.markdown("- **공포형**: 바퀴벌레 1마리 = 30마리가 숨어있다!")
    st.markdown("- **호기심형**: 전문가들이 살충제 대신 이걸 쓰는 이유")
    st.markdown("- **유머형**: 해충들의 최대 적수가 나타났다")


def render_gcs_history(product):
    """GCS 히스토리 표시"""
    st.markdown("#### 📂 GCS 저장 히스토리")

    try:
        # 파이프라인 폴더의 파일 목록
        prefix = f"pipeline/{product['name']}/"
        files = list_gcs_files(GCS_BUCKET_NAME, prefix)

        if not files:
            st.info(f"'{product['name']}' 제품에 대한 저장된 파일이 없습니다.")
            return

        # 파일 타입별 분류
        data_files = []
        strategy_files = []
        thumbnail_files = []
        video_files = []

        for f in files:
            name = f.get("name", "")
            if "collected_data" in name:
                data_files.append(f)
            elif "strategy" in name:
                strategy_files.append(f)
            elif "thumbnail" in name or ".png" in name:
                thumbnail_files.append(f)
            elif ".mp4" in name:
                video_files.append(f)

        # 통계 표시
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("📊 데이터 파일", len(data_files))
        with col2:
            st.metric("🧠 전략 파일", len(strategy_files))
        with col3:
            st.metric("🖼️ 썸네일", len(thumbnail_files))
        with col4:
            st.metric("🎬 영상", len(video_files))

        st.divider()

        # 파일 목록 표시
        if data_files or strategy_files:
            st.markdown("**📄 JSON 파일**")
            for f in sorted(
                data_files + strategy_files,
                key=lambda x: x.get("updated", ""),
                reverse=True,
            )[:5]:
                name = f.get("name", "").split("/")[-1]
                size = f.get("size", 0)
                updated = f.get("updated", "")[:10] if f.get("updated") else ""
                st.markdown(f"- `{name}` ({size} bytes) - {updated}")

        if thumbnail_files:
            st.markdown("**🖼️ 썸네일 파일**")
            for f in sorted(
                thumbnail_files, key=lambda x: x.get("updated", ""), reverse=True
            )[:5]:
                name = f.get("name", "").split("/")[-1]
                st.markdown(f"- `{name}`")

    except Exception as e:
        st.error(f"GCS 파일 목록 조회 실패: {e}")


def render_content_gallery(product):
    """콘텐츠 갤러리 표시"""
    st.markdown("#### 🎯 생성 콘텐츠 갤러리")

    # 현재 세션의 콘텐츠 표시
    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**🖼️ 썸네일**")

        # 3종 썸네일
        if st.session_state.get("multi_thumbnails"):
            for thumb in st.session_state.multi_thumbnails:
                if thumb.get("image"):
                    st.image(thumb["image"], caption=thumb["type"], width=200)

        # 단일 썸네일
        elif st.session_state.get("thumbnail_data"):
            st.image(st.session_state.thumbnail_data, width=300)
        else:
            st.caption("생성된 썸네일이 없습니다.")

    with col2:
        st.markdown("**🎬 영상**")
        if st.session_state.get("video_path"):
            st.video(st.session_state.video_path)
        else:
            st.caption("생성된 영상이 없습니다.")

    st.divider()

    # 통계
    st.markdown("##### 📊 콘텐츠 생성 통계")

    thumb_count = 1 if st.session_state.get("thumbnail_data") else 0
    if st.session_state.get("multi_thumbnails"):
        thumb_count = len(
            [t for t in st.session_state.multi_thumbnails if t.get("image")]
        )

    video_count = 1 if st.session_state.get("video_path") else 0

    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("생성된 썸네일", thumb_count)
    with col2:
        st.metric("생성된 영상", video_count)
    with col3:
        st.metric("총 콘텐츠", thumb_count + video_count)
