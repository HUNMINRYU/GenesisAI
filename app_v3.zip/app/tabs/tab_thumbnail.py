# ==========================================
# 🖼️ 썸네일 생성 탭
# ==========================================
import streamlit as st
from datetime import datetime as dt

from config import BLUEGUARD_PRODUCTS, GCS_BUCKET_NAME, GEMINI_IMAGE_MODEL
from api.gemini import generate_thumbnail, generate_multi_thumbnails
from api.gcs import upload_to_gcs


def render_thumbnail_tab():
    """썸네일 생성 탭 렌더링"""
    st.markdown("##### 🖼️ AI 썸네일 생성")
    st.caption("Gemini 3 Pro Image를 활용한 마케팅 썸네일 생성")

    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    st.info(f"📦 **제품**: {product['name']} - {product['description']}")

    # 생성 모드 선택
    gen_mode = st.radio(
        "생성 모드",
        ["단일 생성", "3종 동시 생성 (공포형/정보형/유머형)"],
        horizontal=True,
    )

    # 후킹 문구 입력
    default_hook = f"{product['name']}! {product['target']} 싹!"
    hook_text = st.text_input(
        "후킹 문구",
        value=default_hook,
        placeholder="썸네일에 들어갈 문구 입력...",
    )

    if gen_mode == "단일 생성":
        # 스타일/색상 선택 (단일 모드만)
        col1, col2 = st.columns(2)
        with col1:
            style = st.selectbox(
                "스타일",
                ["드라마틱", "깔끔한", "공포형", "유머형"],
                index=0,
            )
        with col2:
            color_scheme = st.selectbox(
                "색상 테마",
                ["블루 그라디언트", "레드 경고", "그린 자연", "옐로우 주목"],
                index=0,
            )
    else:
        style = "드라마틱"
        color_scheme = "블루 그라디언트"
        st.caption("💡 3종 모드: 공포형(레드), 정보형(블루), 유머형(옐로우) 자동 적용")

    st.divider()

    # 단일 생성 버튼
    if gen_mode == "단일 생성":
        if st.button("🎨 썸네일 생성", use_container_width=True, type="primary"):
            with st.status("생성 중...", expanded=True) as status:
                st.write(f"🖼️ {GEMINI_IMAGE_MODEL} 이미지 생성 중...")
                st.write(f"📝 후킹 문구: {hook_text}")
                st.write(f"🎨 스타일: {style} / {color_scheme}")

                result = generate_thumbnail(
                    product["name"],
                    hook_text,
                    style=style,
                    color_scheme=color_scheme,
                    logger=status.write,
                )

                if isinstance(result, bytes):
                    st.session_state.thumbnail_data = result
                    st.session_state.multi_thumbnails = None

                    # GCS에 썸네일 업로드
                    date_str = dt.now().strftime("%Y%m%d_%H%M%S")
                    thumbnail_filename = (
                        f"thumbnails/{product['name']}/thumb_{date_str}.png"
                    )

                    if upload_to_gcs(
                        result, GCS_BUCKET_NAME, thumbnail_filename, "image/png"
                    ):
                        status.write(f"☁️ GCS 업로드 완료: {thumbnail_filename}")

                    status.update(
                        label="✅ 썸네일 생성 완료!", state="complete", expanded=False
                    )
                    st.rerun()
                else:
                    status.update(label="❌ 생성 실패", state="error")
                    st.error(result)

    # 3종 동시 생성 버튼
    else:
        if st.button(
            "🎨 3종 썸네일 동시 생성", use_container_width=True, type="primary"
        ):
            with st.status("3종 썸네일 생성 중...", expanded=True) as status:
                st.write(f"🖼️ {GEMINI_IMAGE_MODEL} 3종 스타일 동시 생성")
                st.write(f"📝 베이스 후킹 문구: {hook_text}")

                results = generate_multi_thumbnails(
                    product, hook_text, logger=status.write
                )

                # 결과 저장
                st.session_state.multi_thumbnails = results
                st.session_state.thumbnail_data = None

                # 성공한 이미지들 GCS 업로드
                date_str = dt.now().strftime("%Y%m%d_%H%M%S")
                for r in results:
                    if r["image"]:
                        filename = (
                            f"thumbnails/{product['name']}/{r['type']}_{date_str}.png"
                        )
                        if upload_to_gcs(
                            r["image"], GCS_BUCKET_NAME, filename, "image/png"
                        ):
                            status.write(f"☁️ {r['type']} 업로드 완료")

                status.update(
                    label="✅ 3종 썸네일 생성 완료!", state="complete", expanded=False
                )
                st.rerun()

    # 단일 썸네일 결과 표시
    if st.session_state.get("thumbnail_data"):
        st.divider()
        st.markdown("##### 🖼️ 생성된 썸네일")

        st.image(st.session_state.thumbnail_data, use_container_width=True)

        col1, col2 = st.columns(2)
        with col1:
            st.download_button(
                "📥 PNG 다운로드",
                data=st.session_state.thumbnail_data,
                file_name=f"{product['name']}_thumbnail.png",
                mime="image/png",
                use_container_width=True,
                key="thumbnail_download_png",
            )
        with col2:
            if st.button("🔄 다시 생성", use_container_width=True):
                st.session_state.thumbnail_data = None
                st.rerun()

    # 3종 썸네일 결과 표시
    if st.session_state.get("multi_thumbnails"):
        st.divider()
        st.markdown("##### 🎨 생성된 3종 썸네일")

        cols = st.columns(3)
        for i, thumb in enumerate(st.session_state.multi_thumbnails):
            with cols[i]:
                st.markdown(f"**{thumb['type']}**")
                if thumb["image"]:
                    st.image(thumb["image"], use_container_width=True)
                    st.download_button(
                        f"📥 {thumb['type']}",
                        data=thumb["image"],
                        file_name=f"{product['name']}_{thumb['type']}.png",
                        mime="image/png",
                        use_container_width=True,
                        key=f"thumb_dl_{thumb['type']}",
                    )
                else:
                    st.error(thumb.get("error", "생성 실패"))

        if st.button("🔄 다시 생성", use_container_width=True, key="multi_thumb_reset"):
            st.session_state.multi_thumbnails = None
            st.rerun()
