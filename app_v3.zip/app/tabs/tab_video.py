# ==========================================
# 🎬 영상 생성 탭
# ==========================================
import streamlit as st
from datetime import datetime as dt

from config import BLUEGUARD_PRODUCTS, VEO_MODEL_ID
from api.veo import (
    generate_video_long_running,
    generate_marketing_prompt,
    generate_multi_videos,
)


def render_video_tab():
    """영상 생성 탭 렌더링"""
    st.markdown("##### 🎬 AI 숏폼 영상 생성")
    st.caption("Veo 3.1 Fast를 활용한 마케팅 숏폼 영상 생성")

    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    st.info(f"📦 **제품**: {product['name']} - {product['description']}")

    # 영상 설정
    st.markdown("**⚙️ 영상 설정**")
    col1, col2, col3 = st.columns(3)
    with col1:
        duration = st.selectbox(
            "영상 길이", [8, 15, 30], index=0, format_func=lambda x: f"{x}초"
        )
    with col2:
        resolution = st.selectbox("해상도", ["720p", "1080p"], index=0)
    with col3:
        video_style = st.selectbox(
            "스타일", ["시네마틱", "공포형", "정보형", "유머형"], index=0
        )

    # 스타일 매핑
    style_map = {
        "시네마틱": ("cinematic", "dramatic"),
        "공포형": ("horror", "urgent"),
        "정보형": ("commercial", "hopeful"),
        "유머형": ("commercial", "hopeful"),
    }
    style_key, mood_key = style_map.get(video_style, ("cinematic", "dramatic"))

    st.divider()

    # 후킹 문구 입력
    default_hook = f"{product['name']}! {product['target']} 퇴치!"
    hook_text = st.text_input(
        "후킹 문구", value=default_hook, placeholder="영상에 표시될 후킹 문구..."
    )

    # 프롬프트 영역
    if st.session_state.get("generated_prompt"):
        prompt_value = st.session_state.generated_prompt
    else:
        # 기본 프롬프트 생성 (스타일 적용)
        prompt_value = generate_marketing_prompt(
            product, {"hook": hook_text, "style": style_key, "mood": mood_key}
        )

    with st.expander("📝 프롬프트 보기/수정", expanded=False):
        prompt_text = st.text_area(
            "영상 프롬프트",
            value=prompt_value,
            height=200,
            placeholder="영상 생성 프롬프트를 입력하세요...",
        )

    prompt_text = prompt_text if "prompt_text" in dir() else prompt_value

    # 모델 정보
    st.caption(
        f"🎥 모델: {VEO_MODEL_ID} | 길이: {duration}초 | 해상도: {resolution} | 스타일: {video_style}"
    )

    st.divider()

    if st.button("🎬 숏폼 영상 생성", use_container_width=True, type="primary"):
        with st.status("영상 생성 중...", expanded=True) as status:
            wait_time = "2분" if duration == 8 else "3-4분"
            st.write(f"⚠️ 영상 생성은 약 {wait_time} 정도 소요됩니다.")
            st.write(f"🎬 설정: {duration}초, {resolution}, {video_style}")

            result = generate_video_long_running(
                prompt_text,
                logger=status.write,
                duration_seconds=duration,
                resolution=resolution,
            )

            if isinstance(result, bytes):
                # 로컬 저장
                date_str = dt.now().strftime("%Y%m%d_%H%M%S")
                video_path = f"{product['name']}_shortform_{date_str}.mp4"
                with open(video_path, "wb") as f:
                    f.write(result)

                st.session_state.video_path = video_path
                st.session_state.video_data = result
                st.session_state.step3_done = True

                status.update(
                    label="✅ 영상 생성 완료!", state="complete", expanded=False
                )
                st.balloons()
                st.rerun()
            else:
                status.update(label="ℹ️ 처리 중", state="running")
                st.info(result)

    # 3종 프롬프트 생성 (생성만)
    st.markdown("---")
    st.markdown("**💡 3종 스타일 프롬프트 생성**")
    st.caption("공포형/정보형/유머형 프롬프트를 한번에 생성합니다 (영상 생성은 별도)")

    if st.button("📝 3종 프롬프트 생성", use_container_width=True):
        with st.spinner("3종 프롬프트 생성 중..."):
            prompts = generate_multi_videos(
                product, hook_text, duration_seconds=duration
            )
            st.session_state.multi_video_prompts = prompts
            st.rerun()

    if st.session_state.get("multi_video_prompts"):
        for p in st.session_state.multi_video_prompts:
            with st.expander(f"🎬 {p['type']} ({p['duration']}초)", expanded=False):
                st.text_area(
                    "프롬프트", value=p["prompt"], height=150, key=f"vp_{p['type']}"
                )
                if st.button(f"이 프롬프트로 생성", key=f"gen_{p['type']}"):
                    st.session_state.generated_prompt = p["prompt"]
                    st.rerun()

    # 생성된 영상 표시
    if st.session_state.get("video_path"):
        st.divider()
        st.markdown("##### 🎬 생성된 영상")

        try:
            st.video(st.session_state.video_path)

            col1, col2 = st.columns(2)
            with col1:
                with open(st.session_state.video_path, "rb") as f:
                    st.download_button(
                        "📥 MP4 다운로드",
                        data=f.read(),
                        file_name=f"{product['name']}_shortform.mp4",
                        mime="video/mp4",
                        use_container_width=True,
                        key="video_download_mp4",
                    )
            with col2:
                if st.button("🔄 다시 생성", use_container_width=True):
                    st.session_state.video_path = None
                    st.rerun()

        except Exception as e:
            st.error(f"영상 로드 실패: {e}")
            st.session_state.video_path = None
