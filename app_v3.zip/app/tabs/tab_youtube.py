# ==========================================
# 📺 YouTube 데이터 수집 탭
# ==========================================
import streamlit as st
import datetime

from config import BLUEGUARD_PRODUCTS, GCS_BUCKET_NAME
from api.youtube import search_youtube_videos, get_transcript
from api.gcs import upload_to_gcs
from styles import render_metric_card


def render_youtube_tab():
    """YouTube 데이터 수집 탭 렌더링"""
    st.markdown("##### 📰 YouTube 데이터 수집")
    st.caption("제품 관련 YouTube 영상 검색 및 자막 수집")

    product = st.session_state.get("selected_product", BLUEGUARD_PRODUCTS[0])

    with st.form("collect_form"):
        # 제품 기반 기본 키워드
        default_keyword = f"{product['name']} {product['target']} 퇴치"

        col1, col2 = st.columns([3, 1])
        with col1:
            keyword = st.text_input(
                "검색 키워드",
                value=default_keyword,
                label_visibility="collapsed",
                placeholder="검색어 입력...",
            )
        with col2:
            max_results = st.number_input(
                "수", min_value=1, max_value=10, value=3, label_visibility="collapsed"
            )

        submitted = st.form_submit_button("🚀 수집 시작", use_container_width=True)

        if submitted:
            with st.status("수집 중...", expanded=True) as status:
                st.write("🔍 유튜브 검색...")
                videos = search_youtube_videos(keyword, max_results)

                data = []
                for i, v in enumerate(videos):
                    st.write(f"📝 {i + 1}/{len(videos)} 처리중...")
                    t = get_transcript(v["id"])
                    txt = t if t else v["description"]
                    if txt.strip():
                        data.append(
                            {
                                "video_id": v["id"],
                                "title": v["title"],
                                "text": txt,
                                "thumbnail": v.get("thumbnail", ""),
                                "channel": v.get("channel", ""),
                            }
                        )

                if data:
                    st.write("☁️ GCS 저장 중...")
                    # 제품명 기반 파일 저장
                    filename = (
                        f"youtube/{product['name']}/raw_{datetime.date.today()}.json"
                    )
                    upload_to_gcs(data, GCS_BUCKET_NAME, filename)

                    st.session_state.collected_data = data
                    st.session_state.step1_done = True
                    status.update(label="✅ 완료!", state="complete", expanded=False)
                    st.rerun()
                else:
                    status.update(label="⚠️ 데이터 없음", state="error")

    # 수집된 데이터 (컴팩트 표시)
    if st.session_state.get("collected_data"):
        st.divider()
        st.markdown("##### 📋 수집된 데이터")

        # 메트릭 카드
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(
                render_metric_card(
                    "🎬", str(len(st.session_state.collected_data)), "수집 영상", "blue"
                ),
                unsafe_allow_html=True,
            )
        with col2:
            total_chars = sum(
                len(d.get("text", "")) for d in st.session_state.collected_data
            )
            st.markdown(
                render_metric_card("📝", f"{total_chars:,}", "총 글자수", "mint"),
                unsafe_allow_html=True,
            )
        with col3:
            avg_len = total_chars // max(len(st.session_state.collected_data), 1)
            st.markdown(
                render_metric_card("📊", f"{avg_len:,}", "평균 길이", "purple"),
                unsafe_allow_html=True,
            )

        st.divider()

        # 데이터 리스트
        for i, item in enumerate(st.session_state.collected_data[:5]):
            title_short = (
                item["title"][:50] + "..." if len(item["title"]) > 50 else item["title"]
            )
            with st.expander(f"📹 {i + 1}. {title_short}"):
                st.markdown(f"**제목**: {item['title']}")
                if item.get("channel"):
                    st.markdown(f"**채널**: {item['channel']}")
                st.markdown(f"**내용 미리보기**: {item['text'][:200]}...")
